// JavaScript Document
    function DeleteConfirm()
{
	
  if (confirm('Are you sure you want to delete ? '))
  {
      return true;
  }
  else
  {
      return false;
  }
}