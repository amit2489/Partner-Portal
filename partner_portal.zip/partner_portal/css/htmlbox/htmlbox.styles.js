document.htmlbox_styles=function(){
return [
    [
	'Pull Orange - Right',
	'<br /><div style="float: right; width: 150px; margin: 10px; padding:5px; background:gold; border:1px solid maroon;color:black;font-family: Arial,Helvetica,Georgia;font-weight:bold;line-height:140%;}">',
	'</div><br />'
	],
	[
	'Pull Orange - Left',
	'<br /><div style="float: left; width: 150px; margin: 10px; padding:5px; background:gold; border:1px solid maroon;color:black;font-family: Arial,Helvetica,Georgia;font-weight:bold;line-height:140%;}">',
	'</div><br />'
	],
	[
	'Curly',
	'<br /><table cellspacing="0" cellpadding="0"><tr><td style="border-top:1px solid #b8b8b8;border-left:1px solid #b8b8b8;padding-top:5px;padding-left:5px;">',
	'</td><td style="border-top:1px solid #b8b8b8;border-right:1px solid #b8b8b8;font-size:1px;width:21px;height:17px;">&nbsp;</td></tr><tr><td width="*" style="border-bottom:1px solid #b8b8b8;border-left:1px solid #b8b8b8;font-size:1px;">&nbsp;</td><td style="width:21px;height:17px;"><img src="images/corner.gif" style="width:21px;height:17px;"></td></tr></table><br />'
	]
];
};