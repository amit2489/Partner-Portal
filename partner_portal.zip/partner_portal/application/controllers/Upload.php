<?php

class Upload extends CI_Controller {

        protected $data;
        public function __construct()
        {
            
                parent::__construct();
                date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->model("viewmodel");
                        $this->load->helper(array('form', 'url'));
                        $this->load->library('form_validation');
                        $this->load->helper('date');
        }

        public function view()
        {
             $this->data["insurer"] = json_decode($this->viewmodel->fetch_insurer(),true);
             $this->data["policy"] = json_decode($this->viewmodel->fetch_policy(),true);
             $this->data["files"] = json_decode($this->viewmodel->fetch_files(),true);
                $this->load->view('home_page.php',$this->data);
        }

        public function do_upload()
        {
            
//                $fileName = $_FILES['file']['name'];
//                $config['upload_path']          = '/uploads/';
//                $config['allowed_types']        = '*';
//                $config['max_size']             = 0;
//                $config['max_width']            = 0;
//                $config['max_height']           = 0;
//
//                $this->load->library('upload', $config);
                
                
                
                
                
                $targetDir = "uploads/";
    $fileName = $_FILES['file']['name'];
    $targetFile = $targetDir.$fileName;
    $data['file_name']=$fileName;
//$this->Add_model->files($fileName);
   
    
    if(move_uploaded_file($_FILES['file']['tmp_name'],$targetFile)){
        
        //$this->Add_model->files($fileName);
        
        
        $abc = json_decode($this->Add_model->files($fileName),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
                                                //$this->load->view(home_page);
						redirect('Upload/index');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Upload/index');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Upload/index');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Upload/index');
					}
        
    }


        }
        
    }
        //$now = date('Y-m-d H:i:s');
        //$this->Add_model->files($fileName,$now);
//        
//        
//}
?>