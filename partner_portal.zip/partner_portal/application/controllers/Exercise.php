<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exercise extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
		        $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->helper(array('form', 'url'));
                        $this->load->library('form_validation');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
		}
		
	
	
	
	 public function form()
	        {
			   $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
			   $this->load->view('Exercise_form',$this->data);
		       $this->load->view('footer',$this->data);
	        }
	
	
	public function Add()
	{
		
	 $Option = $this->input->post('Option');
         $days = $this->input->post('days');
	 $title = $this->input->post('title');	
	 $description = $this->input->post('description');
	 $pollopt = $this->input->post('pollopt');
	 $dropdwn = $this->input->post('dropdwn');
	 $dropdown = $this->input->post('dropdown');
		
		
		
		   $this->form_validation->set_rules('title','title','required');
		   $this->form_validation->set_rules('description','description','required');
		
		     if($this->form_validation->run() == FALSE)
                {
                  $this->load->view('Exercise_form',$this->data);
                }
                else
                {
					
					$abc = json_decode($this->Add_model->Exercise($Option,$title,$description,$days,$pollopt,$dropdwn,$dropdown),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
						redirect('Exercise/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Exercise/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Exercise/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Exercise/form');
					}
					
					
				}
		}
	
	
	
	public function edit()
	{
      /*$eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	   $this->data["eid"]=$this->uri->segment(3);
	   $this->data["get_results"] = json_decode($this->Edit_model->get_Exercise($eid),true);
	   $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	   $this->load->view("Exercise_form",$this->data);
	   $this->load->view('footer',$this->data);
	  }
	   else
	   {
		  redirect('Exercise/view');
       }*/
	   
	   
	   
	   
	   
	  $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	    $this->data["eid"]=$this->uri->segment(3);
	    $config = array();
	    $table_name="exercise_option";
	    $config["base_url"] = base_url()."Exercise/edit";
            $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
            $config["per_page"] = 20;
            $config["uri_segment"] = 3;
	    $this->pagination->initialize($config);
            $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
	    $this->data["get_results"] = json_decode($this->Edit_model->get_Exercise($eid),true);
	    $this->data["result"] = json_decode($this->viewmodel->fetch_option($eid),true);
	    $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		
	    $this->data["links"] = $this->pagination->create_links();
	    $this->data["counter"]=$page+1;
	    $this->load->view("edit_question",$this->data);
	    $this->load->view('footer',$this->data);
	  }
	  else
	  {
		  redirect('Question/view');

	  }
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	}
	
	
	
	public function view()
	{
	 
		$config = array();
		$table_name="exercise";
        $config["base_url"] = base_url()."Exercise/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_Exercise($config["per_page"],$page),true);
		
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("Exercise_view",$this->data);
		$this->load->view('footer',$this->data);
	}	
	
	
	
	
	
	public function update()
	{
		$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		
if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;
		
	$days = $this->input->post('days');
	$title = $this->input->post('title');	
	$description = $this->input->post('description');	
	$pollopt = $this->input->post('pollopt');
	$dropdwn = $this->input->post('dropdwn');
	$dropdown = $this->input->post('dropdown');		
		
		   $this->form_validation->set_rules('title','title','required');
		   $this->form_validation->set_rules('description','description','required');
		
		     if($this->form_validation->run() == FALSE)
                {
				  
                  $this->load->view('Exercise_form',$this->data);
                }
                else
                {
		$abc = json_decode($this->Edit_model->update_Exercise($eid,$title,$description,$days,$pollopt,$dropdwn,$dropdown),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Updated sucessfully.");
						redirect('Exercise/edit/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Updated sucessfully.");
						redirect('Exercise/edit/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Exercise/edit/'.$eid);
					}
					
					
					
					
					
					
					
					
					
					
					}
	
	}
	
	
//-----------------------------------------------------------------------------------------------------------//		

public function percent()
{
	
	
	if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;	
	
	
	 $pp = $this->input->post('txtPassportNumber');
	
	
	  $this->form_validation->set_rules('txtPassportNumber', 'Number', 'required');
	  
	 if ($this->form_validation->run() == FALSE)
                {
                        //redirect('Exercise_view',$this->data);
						 //$this->load->view("Exercise_view",$this->data);
                }
                else
                {
					
					
				$abc = json_decode($this->Add_model->update_percent($eid,$pp),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Updated sucessfully.");
						redirect('Exercise/view');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Updated sucessfully.");
						redirect('Exercise/view');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Exercise/view');
					}	
					
					
					
					
					
					
					
					
					
					
					
					
					}
	
	}















//-----------------------------------------------------------------------------------------------------------//			
	
	
	
	
	
	
	
			
			
}



?>