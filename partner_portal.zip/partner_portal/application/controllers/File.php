 
    <?php
 class File extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
                        $this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
                        $this->load->helper(array('form', 'url'));
                        $this->load->library('form_validation');
                }        
    
                public function add()
                {
        $file_id=$this->input->post('id');
        $policy = $this->input->post('policy');
	$policy_id = $this->input->post('type');
        $insurer_id = $this->input->post('insurer');
        $policy_holder = $this->input->post('policy_holder');
        $mobile = $this->input->post('mobile');
        $email = $this->input->post('email');
    
        
        
        					$abc = json_decode($this->Add_model->uploaded_policy($file_id,$policy,$policy_id,$insurer_id,$policy_holder,$mobile,$email),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('success',"Added successfully.");
						redirect('home');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added successfully.");
						redirect('home');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Upload/index');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Upload/index');
					}
        
       //$conn->query("INSERT INTO d_uploaded_policy (policy_id,policy,insurer_id,policy_holder_name,mobile,email_id,file_id) VALUES('".$policy_id."','".$policy."','".$insurer_id."','".$policy_holder."','".$mobile."','".$email."','".$file_id."')");
//      $query="INSERT INTO d_uploaded_policy (type,insurer_name,policy_holder_name,mobile,email_id,file_id) VALUES('".$type."','".$insurer_name."','".$policy_holder."','".$mobile."','".$email."','".$id."')";
//       if(mysql_query($query))
//            {
//            echo "Success";
//            header("Location: fullscreen.php");
//
//            }
//            else
//            {
//             header("Location: fullscreen.php");
//
//            }
                }
}
        ?>

