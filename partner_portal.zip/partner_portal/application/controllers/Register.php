<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Home_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
			$this->load->model("Edit_model");
		        $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			//$this->load->view('footer');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
			
		
		}
		
		
		
	public function view()
	{
	 
		$config = array();
		$table_name="registration";
        $config["base_url"] = base_url()."Register/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_user($config["per_page"],$page),true);
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_registeruser",$this->data);
		$this->load->view('footer',$this->data);
		
	  
	 // $this->load->view('view_registeruser');
	  
	}	
		
		public function edit()
	{
			$eid=$this->uri->segment(3);
			if(isset($eid) && !empty($eid))
			{
			$this->data["eid"]=$this->uri->segment(3);
			$config = array();
			$table_name="question_answer";
			$config["base_url"] = base_url()."Register/edit";
			$config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
			$config["per_page"] = 20;
			$config["uri_segment"] = 3;
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			
			
			$this->data["get_results"] = json_decode($this->Edit_model->get_users($eid),true);
			
			
			$this->data["links"] = $this->pagination->create_links();
			$this->data["counter"]=$page+1;
				$this->load->view('registration_edit',$this->data);
			$this->load->view('footer',$this->data);
			}
			else
			{
			redirect('Register/view');
			
			}
			
		
	
	}	
		
		
		public function update()
	{
		if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;	
	
		
	
	
	
	
	$start_date = $this->input->post('start_date');
	$belief = $this->input->post('belief');	
	
	
	$abc = json_decode($this->Edit_model->update_users($eid,$start_date,$belief),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully & Status Change Successfully.");
						
						  


                                                  $query=$this->db->query("SELECT * FROM registration WHERE reg_id='$eid' AND status=1");
						  if(isset($query) && $query!="")
						  {
						   foreach($query->result_array() as $rows)
						  {
							 $reg_id=$rows['reg_id']; 
							 $name=$rows['name'];
							 $email=$rows['email'];
							 $password=$rows['password'];
						         $sd=$rows['start_date'];
						 
						
						
						
			   /*----------------------------------------------------------------------------------------*/			 
			    $to= "$email";
                            $subject = "Register Successfully";
                            $message = " 
                                <html>
                                <head>
                                <title>Welcome to Upter</title>
                                </head>
                                <body>
                                <h1>Thanks you for joining with us!</h1>
                                <table cellspacing='0' style='border: 2px dashed #FB4314; width: 500px; height: 200px;'>
                                <tr>
                                <th>Username:</th><td>$email</td>
                                </tr>
                                <tr style='background-color: #e0e0e0;'>
                                <th>Password:</th><td>$password</td>
                                </tr>
                                <tr>
                                <th>start Date:</th><td>$sd</td>
                                </tr>

                                </table>
                                </body>
                                </html>
                                ";
                            $headers = "MIME-Version: 1.0" . "\r\n";
                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                            $headers = "From: webmaster@example.com" . "\r\n" . mail($to, $subject, $message, $headers);	 
							/*------------------------------------------------------------------------*/ 	
				 }	}	
						
					redirect('Register/edit/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
							redirect('Register/edit/'.$eid);
					}
					else if($abc==4)
					{
						$this->session->set_flashdata('error',"Date is Empty.");
							redirect('Register/edit/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
							redirect('Register/edit/'.$eid);					}
	}
		
		
		
		
		
		
		
		
		
		
	
}
?>