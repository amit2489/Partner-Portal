<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Visionboard extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Home_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
                        $this->load->model("Searchmodel");
		        $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
			
		
		}
		
		
		
	public function view()
	{
	 
		$config = array();
		$table_name="vision_board";
        $config["base_url"] = base_url()."Visionboard/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_userlist($config["per_page"],$page),true);
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_visionboard",$this->data);
		$this->load->view('footer',$this->data);
		
	  
	 
	  
	}	
		
		
		
		
	public function view_img()
	{
		
		
	  $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	    $this->data["eid"]=$this->uri->segment(3);
	    $config = array();
		$table_name="vision_board";
	    $config["base_url"] = base_url()."Visionboard/view_img";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		
	    $this->data["get_results"] = json_decode($this->viewmodel->fetch_Image($eid),true);
		
	  	//$this->data["result"] = json_decode($this->viewmodel->fetch_option($eid),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;
	    $this->load->view("view_Image",$this->data);
	    $this->load->view('footer');
	  }
	  else
	  {
		  redirect('Visionboard/view');

	  }
		
		
		
		
		
		}	
		
		
		
		
		
		
		
		
		
		
	
}
?>