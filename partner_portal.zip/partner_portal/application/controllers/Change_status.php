<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Change_status extends CI_Controller {
    protected $data;
	public function __construct()
    {   
        parent::__construct();
		date_default_timezone_set('Asia/Kolkata');
		$this->load->library('session');
	        $this->load->helper('url');
                $this->load->library('email');
		$this->load->model("Admin_model");
		$this->load->model("Status_model");
		
		if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
	
	}
	

public function user_status()
	{

	 
	
	
	 if(isset($_POST['excel']))
	 {
	 $id=$_POST['excel'];
	 }
	 
	 
		 if(isset($id) && !empty($id))
		 {
					 	       $get_stat = json_decode($this->Status_model->user_status($id),true);
				
							 if($get_stat == 1)
							  {
							  $ids = join("','",$id);
							  $query=$this->db->query("SELECT * FROM registration WHERE reg_id IN ('$ids') AND status=1");
                                                          if(isset($query) && $query!="")
		                                   {
			  		           foreach($query->result_array() as $rows)
					          {
					                         $reg_id=$rows['reg_id']; 
								 $name=$rows['name'];
								 $email=$rows['email'];
								 $password=$rows['password'];
                                                                 $sds=$rows['start_date'];
                                                                 $mydattee = strtoTime($sds);
                                                                 $printdate = date('F d, Y', $mydattee); 
							 
					/*----------------------------------------------------------------------------------------*/			 
							
                            $message = " 
                                <html>
                                <head>
                                <title>Welcome to Upter</title>
                                </head>
                                <body>
                                <h1>Thanks you for joining with us!</h1>
                                <table cellspacing='0' style='border: 2px dashed #FB4314; width: 500px; height: 200px;'>
                                <tr>
                                <th>Username:</th><td>$email</td>
                                </tr>
                                <tr style='background-color: #e0e0e0;'>
                                <th>Password:</th><td>$password</td>
                                </tr>
                                <tr>
                                <th>Start Date of Your Course is:</th><td>$printdate</td>
                                </tr>
                                </table>
                                </body>
                                </html>
                                ";
                            $this->email->set_newline("\r\n");
                            $this->email->set_mailtype("html");

                            $from_email = "your@example.com"; 
                            $to_email = $this->input->post('email'); 
   
                           //Load email library 
                           $this->load->library('email'); 
                                   
                           $this->email->from($from_email, 'Upter'); 
                           $this->email->to($email);
                           $this->email->subject('Registration Successful'); 
                           $this->email->message($message);
                           $this->email->send();
                           


                     }}




	 
								/*------------------------------------------------------------------------*/ 
								 $this->session->set_flashdata('sucess',"status change sucessfully.");
								 redirect('Register/view');
								 
								 }
								else if($get_stat == 2)
								{
									
									$this->session->set_flashdata('error',"Not change sucessfully.");
									redirect('Register/view');
									
								}
								else
								{
									echo "<p class=err>Sorry,try again!</p>";
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Register/view');
								}
					
		 }
		 else
		 {
			echo "<p class=err>Sorry,try again!</p>";
			$this->session->set_flashdata('error',"Please select something to change status!."); 
			redirect('Register/view');
		 }
	
	
	}
	
//------------------------------------------------------------------------------------------------------------------//





 public function company_status()
	{
     
	  if(isset($_POST['excel']))
	 {
	 $id=$_POST['excel'];
	 }
	 
	 
		 if(isset($id) && !empty($id))
		 {
					 	       $get_stat = json_decode($this->Status_model->company_status($id),true);
				               if($get_stat == 1)
							   {
							     $this->session->set_flashdata('sucess',"status change sucessfully.");
								 redirect('company/view');
							    }
								else if($get_stat == 2)
								{
								  $this->session->set_flashdata('error',"Not change sucessfully.");
								  redirect('company/view');
								}
								else
								{
									
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('company/view');
								}
					
		 
	
	
		 }
		 
		 }

//---------------------------------------------------------------------------------------------------------------------//
}
