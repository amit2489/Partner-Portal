<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Belief extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
		    $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
		}
		
	
	
	
	 public function form()
	        {
		   $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);	   
                   $this->load->view('Belief_form',$this->data);
		   $this->load->view('footer',$this->data);
	        }
	
	
	public function Add()
	{
	
         $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	
        $days = $this->input->post('days');
	$belief = $this->input->post('belief');	
	$title = $this->input->post('title');	
	$description = $this->input->post('description');	
		
		
		   $this->form_validation->set_rules('title','title','required');
		   $this->form_validation->set_rules('description','description','required');
		
		     if($this->form_validation->run() == FALSE)
                {
                  $this->load->view('Belief_form',$this->data);
                }
                else
                {
					
					$abc = json_decode($this->Add_model->Belief($belief,$title,$days,$description),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
						redirect('Belief/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Belief/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Belief/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Belief/form');
					}
					
					
				}
		}
	
	
	
	public function edit()
	{
          $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	   $this->data["eid"]=$this->uri->segment(3);
           $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	   $this->data["get_results"] = json_decode($this->Edit_model->get_Belief($eid),true);
	   $this->load->view("Belief_form",$this->data);
	   $this->load->view('footer',$this->data);
	  }
	   else
	   {
		  redirect('Belief/view');
       }
	}
	
	
	
	public function view()
	{
	 
		$config = array();
		$table_name="belief";
        $config["base_url"] = base_url()."Belief/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_Belief($config["per_page"],$page),true);
		
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("Belief_view",$this->data);
		$this->load->view('footer',$this->data);
	}	
	
	
	
	
	
	public function update()
	{
		$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
            if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;
		
	$days = $this->input->post('days');
        $belief = $this->input->post('belief');	
	$title = $this->input->post('title');	
	$description = $this->input->post('description');	
		
		
		   $this->form_validation->set_rules('title','title','required');
		   $this->form_validation->set_rules('description','description','required');
		
		     if($this->form_validation->run() == FALSE)
                {
                  $this->load->view('Belief_form',$this->data);
                }
                else
                {
					$abc = json_decode($this->Edit_model->update_Belief($eid,$belief,$title,$days,$description),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Updated sucessfully.");
						redirect('Belief/edit/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Updated sucessfully.");
						redirect('Belief/edit/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Belief/edit/'.$eid);
					}
					
					
					
					
					
					
					
					
					
					
					}
	
	}
	
	
	
	
	
	
	
	
	
	
			
			
}



?>