<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SearchData extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Home_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
			$this->load->model("Searchmodel");
		   
			
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
			
		
		}
		
		
		
		public function search()
	   {
		
		 $search=$this->input->get('q');//esi	
		$data['get_table']=json_decode($this->Searchmodel->get_user_details($search),true);
		$this->load->view('view_search',$data);	
	  }	
		
		
		
		
		
		
		
		
		
}
?>