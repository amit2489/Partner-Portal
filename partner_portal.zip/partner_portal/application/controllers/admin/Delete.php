<?php 
ob_start();
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Delete extends CI_Controller {

    protected $data;
	public function __construct()
    {   
        parent::__construct();
		date_default_timezone_set('Asia/Kolkata');
		$this->load->library('session');
	        $this->load->helper('url');
                $this->load->library('email');
		$this->load->model("Add_model");
		$this->load->model("viewmodel");
		$this->load->model("Edit_model");
		$this->load->model("Delete_model");
		
		if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
	}
	
   
 
   public function delete_question()
   {
	$del_id=$this->uri->segment(3); 
	  
  // if(isset($_POST['del_id']) && $_POST['del_id']!=""){$del_id=$this->security->xss_clean($_POST['del_id']);}else{$del_id="";}
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_question($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('sucess',"Delete sucessfully.");
									redirect('Question/view');
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Delete sucessfully.");
									redirect('Question/view');
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Question/view');
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Question/view'); 
		 }
	
	
	}
	
	

   public function delete_option()
   {
	 $del_id=$this->uri->segment(3); 
	 $eid=$this->uri->segment(4);
	  
  
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_option($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('sucess',"Delete sucessfully.");
									redirect('Exercise/edit/'.$eid);
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Delete sucessfully.");
									redirect('Exercise/edit/'.$eid);
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Exercise/edit/'.$eid);
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Exercise/edit/'.$del_id); 
		 }
	
	
	}	
	

	 public function delete_agent()
   {
	 $del_id=$this->uri->segment(3); 
	  
 
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_agents($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('sucess',"Deleted sucessfully.");
									redirect('Agent/view');
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Deleted sucessfully.");
									redirect('Agent/view');
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Agent/view');
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Register/view'); 
		 }
	
	
	}


        
        
        	 public function delete_insurer()
   {
	 $del_id=$this->uri->segment(3); 
	  
 
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_insurer($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('success',"Deleted successfully.");
									redirect('Insurer/view');
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Deleted successfully.");
									redirect('Insurer/view');
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Insurer/view');
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Insurer/view'); 
		 }
	
	
	}


        
        
         public function delete_policy()
   {
	 $del_id=$this->uri->segment(3); 
	  
 
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_policy($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('success',"Deleted successfully.");
									redirect('Policy/view');
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Deleted successfully.");
									redirect('Policy/view');
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Policy/view');
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Policy/view'); 
		 }
	
	
	}





 public function delete_img()
   {
	 $del_id=$this->uri->segment(3); 
	 $eid=$this->uri->segment(4); 
 
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_img($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('sucess',"Delete sucessfully.");
									redirect('Visionboard/view_img/'.$eid);
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Delete sucessfully.");
									redirect('Visionboard/view_img/'.$eid);
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Visionboard/view_img/'.$eid);
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Visionboard/view_img'); 
		 }
	
	
	}



public function delete_Belief()
   {
	 $del_id=$this->uri->segment(3); 
	 
 
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_Belief($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('sucess',"Delete sucessfully.");
									redirect('Belief/view');
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Delete sucessfully.");
									redirect('Belief/view');
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Belief/view');
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Belief/view');
		 }
	
	
	}
public function delete_exercise()
   {
	 $del_id=$this->uri->segment(3); 
	 
 
   if(isset($del_id) && !empty($del_id))
		 {
					 	       $get_delete = json_decode($this->Delete_model->delete_exercise($del_id),true);
				
								if($get_delete == 1)
								{
									
									$this->session->set_flashdata('sucess',"Delete sucessfully.");
									redirect('Exercise/view');
								}
								else if($get_delete == 2)
								{
									
									$this->session->set_flashdata('error',"Not Delete sucessfully.");
									redirect('Exercise/view');
								}
								else
								{
									$this->session->set_flashdata('error',"Sorry,try again!.");
									redirect('Exercise/view');
								}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Exercise/view');
		 }
	
	
	}
	




public function delete_emotions()
   {
	 $del_id=$this->uri->segment(3); 
	 if(isset($del_id) && !empty($del_id))
	 {
		$get_delete = json_decode($this->Delete_model->delete_emotions($del_id),true);
		if($get_delete == 1)
		{
		  $this->session->set_flashdata('sucess',"Delete sucessfully.");
		  redirect('Emotions/view');
		}
		else if($get_delete == 2)
		{
			$this->session->set_flashdata('error',"Not Delete sucessfully.");
			redirect('Emotions/view');
		}
		else
		{
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Emotions/view');
		}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Emotions/view');
		 }
	
	
	}




public function delete_option_em()
   {
	 $del_id=$this->uri->segment(3); 
         $eid=$this->uri->segment(4); 

	 if(isset($del_id) && !empty($del_id))
	 {
		$get_delete = json_decode($this->Delete_model->delete_option_em($del_id),true);
		if($get_delete == 1)
		{
		  $this->session->set_flashdata('sucess',"Delete sucessfully.");
		 redirect('Emotions/edit/'.$eid);
		}
		else if($get_delete == 2)
		{
			$this->session->set_flashdata('error',"Not Delete sucessfully.");
			redirect('Emotions/edit/'.$eid);
		}
		else
		{
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Emotions/edit/'.$eid);
		}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			//redirect('Emotions/view');
			redirect('Emotions/edit/'.$eid);
								
		 }
	
	
	}	
	



public function delete_emotions_sol()
   {
	 $del_id=$this->uri->segment(3); 
	 if(isset($del_id) && !empty($del_id))
	 {
		$get_delete = json_decode($this->Delete_model->delete_emotions_sol($del_id),true);
		if($get_delete == 1)
		{
		  $this->session->set_flashdata('sucess',"Delete sucessfully.");
		  redirect('Emotions/solution_view');
		}
		else if($get_delete == 2)
		{
			$this->session->set_flashdata('error',"Not Delete sucessfully.");
			redirect('Emotions/solution_view');
		}
		else
		{
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Emotions/solution_view');
		}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Emotions/solution_view');
		 }
	
	
	}





public function delete_tips()
   {
	 $del_id=$this->uri->segment(3); 
	 if(isset($del_id) && !empty($del_id))
	 {
		$get_delete = json_decode($this->Delete_model->delete_tips($del_id),true);
		if($get_delete == 1)
		{
		  $this->session->set_flashdata('sucess',"Delete sucessfully.");
		  redirect('Tips/view');
		}
		else if($get_delete == 2)
		{
			$this->session->set_flashdata('error',"Not Delete sucessfully.");
			redirect('Tips/view');
		}
		else
		{
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Tips/view');
		}
					
		 }
		 else
		 {
			
			$this->session->set_flashdata('error',"Sorry,try again!.");
			redirect('Tips/view');
		 }
	
	
	}







	
}
?>
