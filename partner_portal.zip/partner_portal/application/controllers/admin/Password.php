<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Password extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
		        $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->helper(array('form', 'url'));
                        $this->load->library('form_validation');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
		}
		
	
	
	
	 public function form()
	        {
                       $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
                       $this->load->view('password',$this->data);
		       $this->load->view('footer',$this->data);
	        }
public function change()
{
 if(isset($_POST['email']) && $_POST['email']!=""){$email=$this->security->xss_clean($_POST['email']);}else{$email="";}
	   if(isset($_POST['new_pass']) && $_POST['new_pass']!=""){$new_pass=$this->security->xss_clean($_POST['new_pass']);}else{$new_pass="";}
	   if(isset($_POST['old_pass']) && $_POST['old_pass']!=""){$old_pass=$this->security->xss_clean($_POST['old_pass']);}else{$old_pass="";}
	   if(isset($_POST['con_pass']) && $_POST['con_pass']!=""){$con_pass=$this->security->xss_clean($_POST['con_pass']);}else{$con_pass="";}
$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('old_pass', 'Old Password', 'required');
		$this->form_validation->set_rules('new_pass', 'New Password', 'trim|required|min_length[3]');
$this->form_validation->set_rules('new_pass', 'New Password', 'trim|required|min_length[3]');
	 $this->form_validation->set_rules('con_pass', 'Confirm password', 'trim|required|min_length[3]|matches[new_pass]');

		if ($this->form_validation->run() == FALSE)
		{
		// $this->load->view('header');
		//	$this->load->view('sidebar',$this->data);
$this->load->view('password',$this->data);
		       $this->load->view('footer',$this->data);
		}else
{
$add=$this->Add_model->Change($email,$new_pass,$old_pass,$con_pass);
 if($add==1)
					{
						$this->session->set_flashdata('sucess',"Your Password Updated Sucessfully.");
						redirect('Password/form');
					}
					else if($add==2)
					{
						$this->session->set_flashdata('error',"Invalid Old Password Try Again!");
						redirect('Password/form');
					}
else if($add==3)
					{
						$this->session->set_flashdata('error',"Something went wrong Try Again!");
						redirect('Password/form');
					}else
{
$this->session->set_flashdata('error',"Sorry Try Again!");
						redirect('Password/form');
}


}
}
}