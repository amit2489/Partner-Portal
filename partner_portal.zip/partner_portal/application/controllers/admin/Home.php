<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Home_model");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
		        $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->view('footer');

                        if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		}
	
	
	
	public function home()
	{
	  
	  $this->load->view('blank');
	}
	
	public function Main()
	{
	  
	  $this->load->view('dashboard');
	}
	
	
}

?>