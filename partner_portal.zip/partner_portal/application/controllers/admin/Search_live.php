<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class search_live extends CI_Controller {
protected $data;
	public function __construct()
    {
        parent::__construct();

        $this->load->library('session');
	    $this->load->helper('url');

		$this->load->model("searchmodel");
    }
	
	
	/*public function search_builder()
	{
		
		if(isset($_GET['q']) && $_GET['q']!=""){$svalue=$_GET['q'];}
		else{$svalue="null";}
		
		$json_response=$this->data["live_search"]=$this->searchmodel->builder_search_get($svalue);
		//$this->load->view("live_search_view",$this->data);
		//$this->load->view("news_form",$this->data);
		if(isset($_GET["callback"])) 
		{
        $json_response = $_GET["callback"] . "(" . $json_response . ")";
        }
		echo $json_response;
	}*/
	
	
	
	public function search_user()
	{
		
		if(isset($_GET['q']) && $_GET['q']!=""){$user=$_GET['q'];}
		else{$user="null";}
		
		$json_response=$this->data["live_search"]=$this->searchmodel->search_user($user);
		
		if(isset($_GET["callback"])) 
		{
        $json_response = $_GET["callback"] . "(" . $json_response . ")";
        }
		echo $json_response;
	}
	


	
	
	
	
	
	
	
	
	
	
	
	
}

