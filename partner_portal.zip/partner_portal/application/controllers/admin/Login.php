<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

    protected $data;
	
    public function __construct()
    {   
               parent::__construct();
		date_default_timezone_set('Asia/Kolkata');
		
		$this->load->library('session');
	        $this->load->helper('url');
		$this->load->model("Admin_model");
	
   }
	
	
	public function index()
	{
	  
	  $this->load->view('login_form');
	}
	
	
	
	public function login()
	{
		//$this->load->view('header');
		$this->load->view('login_form');
		$this->load->view('footer');
	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('Login');
	}
	
	
	
	
	
	
	
	 
	public function adminlogin()
	{
		
	if(isset($_POST['UserName']) && $_POST['UserName']!=""){$UserName=$this->security->xss_clean($_POST['UserName']);}else{$UserName="";}
	if(isset($_POST['Password']) && $_POST['Password']!=""){$Password=$this->security->xss_clean($_POST['Password']);}else{$Password="";}
	
	 
	  
		 if(isset($UserName) && empty($UserName))
		 {
			$this->session->set_flashdata('user','Username are required!');
			 redirect('Login/login');
		 }
		 else if(isset($Password) && empty($Password))
		 {
			 $this->session->set_flashdata('pwd','Password are required!');
			 redirect('Login/login'); 
		 }
		 else if(isset($UserName) && isset($Password) && !empty($UserName) && !empty($Password))
		 {
			 
			
			$getuser_det = $this->Admin_model->get_admin_login($UserName,$Password);
			if($getuser_det==1)
					 {
						 $this->session->set_flashdata('sucesslogin',"Login Successfully.");
						 redirect('Home/home');
						
					 }
					
					else if($getuser_det==2) 
					 {
						 
						$this->session->set_flashdata('errorlogin',"INCORRECT USERNAME AND PASSWORD!");
						redirect('Login/login');
					 }	
								
		 }
		 else
		 {
			echo "All the fields are required!"; 
		 }
	
	
	}
	
	
	
}
