<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agent extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
		    $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
		}
		
	
	
	
	 public function form()
	        {
			   $this->data["agents"] = json_decode($this->viewmodel->fetch_agents(),true);
                           $this->data["subpartner"] = json_decode($this->viewmodel->fetch_sub_partner(),true);
                           
			   $this->load->view('agent_form',$this->data);
		       $this->load->view('footer',$this->data);
	        }
	
	
	public function Add()
	{
		
            $agent_id=$this->input->post('agent');
            $sub_partner_id=$this->input->post('sub_partner');
            $name = $this->input->post('name');
            $address=$this->input->post('address');
            $mobile = $this->input->post('mobile');
            $email=$this->input->post('email');
            $company = $this->input->post('company');
            $person=$this->input->post('person');
            $city = $this->input->post('city');
            $state=$this->input->post('state');
            $pin = $this->input->post('pin');
		
		  
		   $this->form_validation->set_rules('name','name','required');
                   $this->form_validation->set_rules('address','address','required');
                   $this->form_validation->set_rules('mobile','mobile','required');
                   $this->form_validation->set_rules('email','email','required');
          
		
		     if($this->form_validation->run() == FALSE)
                {
                  $this->load->view('agent_form',$this->data);
                }
                else
                {
					if(empty($agent_id) && empty($sub_partner_id))
                                        {
					$abc = json_decode($this->Add_model->agent($name,$address,$mobile,$email,$person,$company,$city,$state,$pin),true);
	                if($abc==1)
					{
                                /*----------------------------------------------------------------------------------------*/			 
                                             $to= "$email";
                                             $subject = "Register Successfully";
                                            $message = " 
                                            <html>
                                            <head>
                                            <title>Greeting from McXtra</title>
                                            </head>
                                            <body>
                                            <h1>Thanks you for joining with us!</h1>
                                            <table cellspacing='0' style='border: 2px dashed #FB4314; width: 500px; height: 200px;'>
                                            <tr>
                                            <th>Username:</th><td>$email</td>
                                            </tr>
                                            <tr style='background-color: #e0e0e0;'>
                                            <th>Password:</th><td>$password</td>
                                            </tr>
                                            <tr>
                                            <th>start Date:</th><td>$sd</td>
                                            </tr>

                                            </table>
                                            </body>
                                            </html>
                                                    ";
                                            $headers = "MIME-Version: 1.0" . "\r\n";
                                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                            $headers = "From: webmaster@example.com" . "\r\n" . mail($to, $subject, $message, $headers);	 
				/*------------------------------------------------------------------------*/ 
						$this->session->set_flashdata('success',"Added sucessfully.");
						redirect('Product/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Agent/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Agent/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Agent/form');
					}
                                        }
                                        
					 
                                        else if(isset($agent_id) && empty($sub_partner_id))
                                        {
					$abc = json_decode($this->Add_model->sub_partner($agent_id,$name,$address,$mobile,$email,$company,$person,$city,$state,$pin),true);
	                if($abc==1)
					{
                                /*----------------------------------------------------------------------------------------*/			 
                                             $to= "$email";
                                             $subject = "Register Successfully";
                                            $message = " 
                                            <html>
                                            <head>
                                            <title>Greeting from McXtra</title>
                                            </head>
                                            <body>
                                            <h1>Thanks you for joining with us!</h1>
                                            <table cellspacing='0' style='border: 2px dashed #FB4314; width: 500px; height: 200px;'>
                                            <tr>
                                            <th>Username:</th><td>$email</td>
                                            </tr>
                                            <tr style='background-color: #e0e0e0;'>
                                            <th>Password:</th><td>$password</td>
                                            </tr>
                                            <tr>
                                            <th>start Date:</th><td>$sd</td>
                                            </tr>

                                            </table>
                                            </body>
                                            </html>
                                                    ";
                                            $headers = "MIME-Version: 1.0" . "\r\n";
                                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                            $headers = "From: webmaster@example.com" . "\r\n" . mail($to, $subject, $message, $headers);	 
				/*------------------------------------------------------------------------*/ 
						$this->session->set_flashdata('success',"Added sucessfully.");
						redirect('Product/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Agent/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Agent/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Agent/form');
					}
                                        }
                                        
                                        
                                 else if(empty($agent_id) && !empty($sub_partner_id))
                                        {
					$abc = json_decode($this->Add_model->sub_sub_partner($sub_partner_id,$name,$address,$mobile,$email,$company,$person,$city,$state,$pin),true);
	                if($abc==1)
					{
                                /*----------------------------------------------------------------------------------------*/			 
                                             $to= "$email";
                                             $subject = "Register Successfully";
                                            $message = " 
                                            <html>
                                            <head>
                                            <title>Greeting from McXtra</title>
                                            </head>
                                            <body>
                                            <h1>Thanks you for joining with us!</h1>
                                            <table cellspacing='0' style='border: 2px dashed #FB4314; width: 500px; height: 200px;'>
                                            <tr>
                                            <th>Username:</th><td>$email</td>
                                            </tr>
                                            <tr style='background-color: #e0e0e0;'>
                                            <th>Password:</th><td>$password</td>
                                            </tr>
                                            <tr>
                                            <th>start Date:</th><td>$sd</td>
                                            </tr>

                                            </table>
                                            </body>
                                            </html>
                                                    ";
                                            $headers = "MIME-Version: 1.0" . "\r\n";
                                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                            $headers = "From: webmaster@example.com" . "\r\n" . mail($to, $subject, $message, $headers);	 
				/*------------------------------------------------------------------------*/ 
						$this->session->set_flashdata('success',"Added sucessfully.");
						redirect('Product/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Agent/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Agent/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Agent/form');
					}
                                        }
                                        
                                    else
                                    {
                                        $this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Agent/form');
                                    }
                                             
                                        
                                        
                                        
                                        
				}
		}
	
	
	
	public function edit()
	{
      $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	   $this->data["eid"]=$this->uri->segment(3);
	   $this->data["get_results"] = json_decode($this->Edit_model->get_agents($eid),true);
	   //$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	   $this->load->view("agent_form",$this->data);
	   $this->load->view('footer',$this->data);
	  }
	   else
	   {
		  redirect('Agent/view');
       }
	}
	
	
	
	public function view()
	{
	 
		$config = array();
		$table_name="d_agent";
        $config["base_url"] = base_url()."Agent/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_agents($config["per_page"],$page),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_agentdetails",$this->data);
		$this->load->view('footer',$this->data);
	}	
        
        
        public function view_subpartner()
	{
	 
		$config = array();
		$table_name="sub_partner";
        $config["base_url"] = base_url()."Agent/view_subpartner";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_sub_partner($config["per_page"],$page),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_subpartner",$this->data);
		$this->load->view('footer',$this->data);
	}	
	
        
        public function view_sub_subpartner()
	{
	 
		$config = array();
		$table_name="sub_sub_partner";
        $config["base_url"] = base_url()."Agent/view_sub_subpartner";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_sub_sub_partner($config["per_page"],$page),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_sub_subpartner",$this->data);
		$this->load->view('footer',$this->data);
	}
        
	
	
	
	
	
	public function update()
	{
		 //$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		
if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;
		
	
	//days = $this->input->post('days');
	$name = $this->input->post('name');	
	$address = $this->input->post('address');
        $mobile = $this->input->post('mobile');
        $email = $this->input->post('email');	
	$person = $this->input->post('person');	
	$company = $this->input->post('company');
        $city = $this->input->post('city');
        $state = $this->input->post('state');
        $pin = $this->input->post('pin');	
		
		  
		    $this->form_validation->set_rules('name','name','required');
                   $this->form_validation->set_rules('address','address','required');
                   $this->form_validation->set_rules('mobile','mobile','required');
                   $this->form_validation->set_rules('email','email','required');
		   if($this->form_validation->run() == FALSE)
			{
			  $this->load->view('agent_form',$this->data);
			}
           else
            {
					$abc = json_decode($this->Edit_model->update_agents($eid,$name,$address,$mobile,$email,$person,$company,$city,$state,$pin),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('success',"Updated sucessfully.");
						redirect('Agent/edit/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Updated sucessfully.");
						redirect('Agent/edit/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Agent/edit/'.$eid);
					}
					
					
					
					
					
					
					
					
					
					
					}
                                        
                                        
                                        
                                        
	
	}
        
        
        public function partner_subpartner()
	{
          
          $agent_id = $this->input->post('agent');
	 
		$config = array();
		$table_name="d_agent";
        $config["base_url"] = base_url()."Agent/partner_subpartner";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["result"] = json_decode($this->viewmodel->fetch_agents(),true);
        $this->data["results"] = json_decode($this->viewmodel->fetch_partner_subpartner($agent_id),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
        
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_partner_subpartner_details",$this->data);
		$this->load->view('footer',$this->data);
	}
	
	
         public function subpartner_subsubpartner()
	{
          
          $subpartner_id = $this->input->post('subpartner');
	 
		$config = array();
		$table_name="sub_partner";
        $config["base_url"] = base_url()."Agent/subpartner_subsubpartner";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["result"] = json_decode($this->viewmodel->fetch_sub_partner(),true);
        $this->data["results"] = json_decode($this->viewmodel->fetch__subpartner_subsubparter($subpartner_id),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
        
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_sub_subpartner_details",$this->data);
		$this->load->view('footer',$this->data);
	}
	
	
	
	
	
	
	
	
			
			
}



?>