<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Question extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
		        $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->helper(array('form', 'url'));
                        $this->load->library('form_validation');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
		}
		
	
	
	
	 public function form()
	        {
                       $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
                       $this->load->view('question_form',$this->data);
		       $this->load->view('footer',$this->data);
	        }
			
	
	public function Add()
	{
	
           $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	/*if(isset($_POST['days']) && $_POST['days']!=""){$days=$this->security->xss_clean($_POST['days']);}else{$days="";}
	if(isset($_POST['seq']) && $_POST['seq']!=""){$seq=$this->security->xss_clean($_POST['seq']);}else{$seq="";}	
	if(isset($_POST['title']) && $_POST['title']!=""){$title=$this->security->xss_clean($_POST['title']);}else{$title="";}
	if(isset($_POST['question']) && $_POST['question']!=""){$question=$this->security->xss_clean($_POST['question']);}else{$question="";}*/
	
	$days = $this->input->post('days');
	$seq = $this->input->post('seq');
        $belief = $this->input->post('belief'); 
	$title = $this->input->post('title');
	$question = $this->input->post('question');

	//$pollopt = $this->input->post('pollopt');
	//$dropdwn = $this->input->post('dropdwn');
	
		
		 $this->form_validation->set_rules('title', 'title', 'required');
		 $this->form_validation->set_rules('days', 'days', 'required');
		 $this->form_validation->set_rules('seq', 'sequence', 'required|numeric');
		 $this->form_validation->set_rules('question', 'quest', 'required');
		
		       if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('question_form',$this->data);
                }
                else
                {
                    $abc = json_decode($this->Add_model->question($title,$days,$seq,$belief,$question),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
						redirect('Question/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Question/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Question/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Question/form');
					}
						
		   } 
		
		
}
	
	
//--------------------------------------------------EDIT------------------------------------------------------//	
	  
	public function edit()
	{
          $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	   $this->data["eid"]=$this->uri->segment(3);
           $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	   $this->data["get_results"] = json_decode($this->Edit_model->get_question($eid),true);
	   $this->load->view("question_form",$this->data);
	   $this->load->view('footer',$this->data);
	  }
	   else
	   {
		  redirect('Question/view');
       }
		
	/*$eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	        $this->data["eid"]=$this->uri->segment(3);
	        $config = array();
		$table_name="question_answer";
	        $config["base_url"] = base_url()."Question/edit";
                $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
                $config["per_page"] = 20;
                $config["uri_segment"] = 3;
		$this->pagination->initialize($config);
                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

		$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	        $this->data["get_results"] = json_decode($this->Edit_model->get_question($eid),true);
		$this->data["result"] = json_decode($this->viewmodel->fetch_option($eid),true);

		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;
	    $this->load->view("edit_question",$this->data);
	    $this->load->view('footer',$this->data);
	  }
	  else
	  {
		  redirect('Question/view');

	  }*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
//-----------------------------------------------------------------------------------------------------//	
	
	
	
	
	
	public function view()
	{
	 
	$config = array();
	$table_name="question";
        $config["base_url"] = base_url()."Question/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_question($config["per_page"],$page),true);
		
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

                $this->load->view("question_view",$this->data);
		$this->load->view('footer',$this->data);
	}	
		
//---------------------------------------Update----------------------------------------------------//		
	public function update()
	{

if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;	

	 $this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
         $this->data["result"] = json_decode($this->viewmodel->fetch_option($eid),true);


	
		
	/*if(isset($_POST['title']) && $_POST['title']!=""){$title=$this->security->xss_clean($_POST['title']);}else{$title="";}
	if(isset($_POST['days']) && $_POST['days']!=""){$days=$this->security->xss_clean($_POST['days']);}else{$days="";}
	if(isset($_POST['question']) && $_POST['question']!=""){$question=$this->security->xss_clean($_POST['question']);}else{$question="";}*/
	
	
	
	/*$days = $this->input->post('days');
	$seq = $this->input->post('seq');
	$title = $this->input->post('title');
	$question = $this->input->post('question');
	$pollopt = $this->input->post('pollopt');
	$dropdwn = $this->input->post('dropdwn');*/
	
	$days = $this->input->post('days');
	$seq = $this->input->post('seq');
	$belief = $this->input->post('belief');
	$title = $this->input->post('title');
	$question = $this->input->post('question');
	
	
	
		 $this->form_validation->set_rules('title', 'title', 'required');
		 $this->form_validation->set_rules('days', 'days', 'required');
		 $this->form_validation->set_rules('seq', 'sequence', 'required|numeric');
		 $this->form_validation->set_rules('question', 'quest', 'required');
		
		       if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('question_form',$this->data);
                }
                else
                {
                   $abc = json_decode($this->Edit_model->update_question($eid,$title,$days,$seq,$belief,$question),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Updated Sucessfully.");
						redirect('Question/edit/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Updated Sucessfully.");
						redirect('Question/edit/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Question/edit/'.$eid);
					}
						
		   } 
		
		
}
		
		
}
?>