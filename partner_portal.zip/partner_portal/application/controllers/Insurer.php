<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insurer extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
		    $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
		}
		
	
	
	
	 public function form()
	        {
			   //$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
			   $this->load->view('insurer_form',$this->data);
		       $this->load->view('footer',$this->data);
	        }
	
	
	public function Add()
	{
		
	
	//$days = $this->input->post('days');
	$name = $this->input->post('name');	
		
		
		  
		   $this->form_validation->set_rules('name','name','required');
		
		     if($this->form_validation->run() == FALSE)
                {
                  $this->load->view('insurer_form',$this->data);
                }
                else
                {
					
					$abc = json_decode($this->Add_model->insurer($name),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('success',"Added sucessfully.");
						redirect('Insurer/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Insurer/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Insurer/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Insurer/form');
					}
					
					
				}
		}
	
	
	
	public function edit()
	{
      $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	   $this->data["eid"]=$this->uri->segment(3);
	   $this->data["get_results"] = json_decode($this->Edit_model->get_insurer($eid),true);
	   //$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
	   $this->load->view("insurer_form",$this->data);
	   $this->load->view('footer',$this->data);
	  }
	   else
	   {
		  redirect('Insurer/view');
       }
	}
	
	
	
	public function view()
	{
	 
		$config = array();
		$table_name="d_insurer";
        $config["base_url"] = base_url()."Insurer/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_insurer($config["per_page"],$page),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_insurerdetails",$this->data);
		$this->load->view('footer',$this->data);
	}	
	
	
	
	
	
	public function update()
	{
		 //$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
		
if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;
		
	
	//days = $this->input->post('days');
	$name = $this->input->post('name');	
		
		
		  
		   $this->form_validation->set_rules('name','name','required');
		   if($this->form_validation->run() == FALSE)
			{
			  $this->load->view('insurer_form',$this->data);
			}
           else
            {
					$abc = json_decode($this->Edit_model->update_insurer($eid,$name),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('success',"Updated sucessfully.");
						redirect('Insurer/edit/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Updated sucessfully.");
						redirect('Insurer/edit/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('insurer/edit/'.$eid);
					}
					
					
					
					
					
					
					
					
					
					
					}
	
	}
	
	
        
        
      public function report()
	{
          
          $insurer_id = $this->input->post('insurer');
	 
		$config = array();
		$table_name="d_uploaded_policy";
        $config["base_url"] = base_url()."Insurer/report";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["result"] = json_decode($this->viewmodel->fetch_insurer(),true);
        $this->data["results"] = json_decode($this->viewmodel->fetch_insurer_policy($insurer_id),true);
		//$this->data["days"] = json_decode($this->viewmodel->fetch_days(),true);
        
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("view_insurer_policy",$this->data);
		$this->load->view('footer',$this->data);
	}  
	
	
	
	
	
	
	
	
			
			
}



?>