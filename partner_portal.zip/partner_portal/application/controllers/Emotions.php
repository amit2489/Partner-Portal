<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Emotions extends CI_Controller 
{
		protected $data;
		public function __construct()
		{   
			parent::__construct();
			date_default_timezone_set('Asia/Kolkata');
			
			$this->load->library('session');
			$this->load->helper('url');
			$this->load->model("Admin_model");
			$this->load->model("Add_model");
			$this->load->model("Edit_model");
			$this->load->library("pagination");
			$this->load->model("Privileges_model");
			$this->data["admin"]=$this->Privileges_model->admin();
			$this->load->model("viewmodel");
		        $this->load->view('header');
			$this->load->view('sidebar',$this->data);
			$this->load->helper(array('form', 'url'));
                        $this->load->library('form_validation');
			
			if(!$this->session->userdata('upter_admin'))
				{
							$session_data = $this->session->userdata('upter_admin');
							$data['username'] = $session_data['username'];
							redirect('Login', 'refresh');
				
				}
		
		
		}
		
	
	
	
	       public function form()
	        {
			   $this->data["emcat"] = json_decode($this->viewmodel->fetch_em_cat(),true);
               $this->load->view('Emotions_form',$this->data);
		       $this->load->view('footer',$this->data);
	        }

                public function solution_form()
	        {
			    $this->data["emcat"] = json_decode($this->viewmodel->fetch_em_cat(),true);
                            $this->load->view('emotions_solution',$this->data);
		            $this->load->view('footer',$this->data);
	        }
			
			
	public function add()
	{
		
		$this->data["emcat"] = json_decode($this->viewmodel->fetch_em_cat(),true);
		
		$days = $this->input->post('days');
		$title = $this->input->post('title');
		$pollopt = $this->input->post('pollopt');
	        $question = $this->input->post('question');
		
		 $this->form_validation->set_rules('days', 'days', 'required');
		 $this->form_validation->set_rules('title', 'title', 'required');
		 $this->form_validation->set_rules('question', 'quest', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('Emotions_form',$this->data);
                }
                else
                {
                    $abc = json_decode($this->Add_model->Emotions($days,$title,$question,$pollopt),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
						redirect('Emotions/form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Emotions/form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Emotions/form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Emotions/form');
					}
						
		   } 
		
		
		}		
			
			
//-------------------------------------------------------------------------------------------------------//

public function view()
	{
	 
		$config = array();
		$table_name="emotions_mgmt";
        $config["base_url"] = base_url()."Emotions/view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_emotions($config["per_page"],$page),true);
		
		$this->data["links"] = $this->pagination->create_links();
		$this->data["counter"]=$page+1;

        $this->load->view("Emotions_view",$this->data);
		$this->load->view('footer',$this->data);
	}				
			
//-------------------------------------------------------------------------------------------------//		
			
   public function edit()
	/*{
      $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	   $this->data["eid"]=$this->uri->segment(3);
	   $this->data["emcat"] = json_decode($this->viewmodel->fetch_em_cat(),true);
	   $this->data["get_results"] = json_decode($this->Edit_model->get_emotion($eid),true);
	   $this->load->view("Emotions_form",$this->data);
	   $this->load->view('footer',$this->data);
	  }
	   else
	   {
		  redirect('Emotions/view');
       }	*/	
	   
	{
	  $eid=$this->uri->segment(3);
	  if(isset($eid) && !empty($eid))
	  {
	    $this->data["eid"]=$this->uri->segment(3);
	    $config=array();
		$table_name="question_answer";
	    $config["base_url"]=base_url()."Question/edit";
        $config["total_rows"]=$this->viewmodel->count_total_rows($table_name);
        $config["per_page"]=20;
        $config["uri_segment"]=3;
		$this->pagination->initialize($config);
        $page=($this->uri->segment(3))?$this->uri->segment(3) : 0;
		
	    $this->data["get_results"]=json_decode($this->Edit_model->get_emotion($eid),true);
		
	  	$this->data["result"]=json_decode($this->viewmodel->fetch_option_em($eid),true);
		$this->data["emcat"]=json_decode($this->viewmodel->fetch_em_cat(),true);
		
		$this->data["links"]=$this->pagination->create_links();
		$this->data["counter"]=$page+1;
	    $this->load->view("edit_emotion",$this->data);
	    $this->load->view('footer',$this->data);
	  }
	  else
	  {
		  redirect('Question/view');

	  }  
	   
	}
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   	
	
	
	//---------------------------------------------------------------------------------------------------//
	
	
	public function update()
	{
		
		
	if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;	
		
		
	$days = $this->input->post('days');
	$title = $this->input->post('title');
    $question = $this->input->post('question');
	$pollopt = $this->input->post('pollopt');	
		
		        $this->form_validation->set_rules('title', 'title', 'required');
		        $this->form_validation->set_rules('days', 'days', 'required');
		        $this->form_validation->set_rules('question', 'quest', 'required');
		
		
		
		
		        if($this->form_validation->run() == FALSE)
                {
                        $this->load->view('Emotions_form');
                }
                else
                {
                   $abc = json_decode($this->Edit_model->update_emotion($eid,$days,$title,$question,$pollopt),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
						redirect('Emotions/edit/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Emotions/edit/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Emotions/edit/'.$eid);
					}
						
		   } 
		
		
		
		
		}
	
	
//-----------------------------------------------------------------------------------------------------------------------------------------------//	
	
	public function solution_add()
        {

            
                      

           $this->data["emcat"] = json_decode($this->viewmodel->fetch_em_cat(),true);
		
		$days = $this->input->post('days');
		$title = $this->input->post('title');
		
	        $question = $this->input->post('question');
		
		 $this->form_validation->set_rules('days', 'days', 'required');
		 $this->form_validation->set_rules('title', 'title', 'required');
		 $this->form_validation->set_rules('question', 'quest', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('Emotions_form',$this->data);
                }
                else
                {
                    $abc = json_decode($this->Add_model->solution($days,$title,$question),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
						redirect('Emotions/solution_form');
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Emotions/solution_form');
					}
					else if($abc==3)
					{
						$this->session->set_flashdata('error',"Insert option.");
						redirect('Emotions/solution_form');
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Emotions/solution_form');
					}
						
		   } 

 }
	
	
	

        public function solution_view()
	{
	 
	$config = array();
	$table_name="emotions_mgmt";
        $config["base_url"] = base_url()."Emotions/solution_view";
        $config["total_rows"] = $this->viewmodel->count_total_rows($table_name);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $this->data["results"] = json_decode($this->viewmodel->fetch_emotions_solution($config["per_page"],$page),true);
	$this->data["links"] = $this->pagination->create_links();
	$this->data["counter"]=$page+1;
        $this->load->view("emotions_solution_view",$this->data);
	$this->load->view('footer',$this->data);
	
       }





 public function edit_sol()
  {
           $eid=$this->uri->segment(3);
	   if(isset($eid) && !empty($eid))
	   {
	   $this->data["eid"]=$this->uri->segment(3);
	   $this->data["emcat"] = json_decode($this->viewmodel->fetch_em_cat(),true);
	   $this->data["get_results"] = json_decode($this->Edit_model->get_emotion_sol($eid),true);
	   $this->load->view("emotions_solution",$this->data);
	   $this->load->view('footer',$this->data);
	   }
	   else
	   {
		  redirect('Emotions/solution_view');
           }	


}



public function solution_update()
	{
		
		
	if(isset($_POST['eid']) && $_POST['eid']!=""){$eid=$this->security->xss_clean($_POST['eid']);}else{$eid="";}$this->data["eid"]=$eid;	
		
		
	$days = $this->input->post('days');
	$title = $this->input->post('title');
        $question = $this->input->post('question');
		
		
		        $this->form_validation->set_rules('title', 'title', 'required');
		        $this->form_validation->set_rules('days', 'days', 'required');
		        $this->form_validation->set_rules('question', 'quest', 'required');
		
		
		
		
		        if($this->form_validation->run() == FALSE)
                {
                        $this->load->view('emotions_solution');
                }
                else
                {
                   $abc = json_decode($this->Edit_model->update_solution($eid,$days,$title,$question),true);
	                if($abc==1)
					{
						$this->session->set_flashdata('sucess',"Added sucessfully.");
						redirect('Emotions/edit_sol/'.$eid);
					}
					else if($abc==2)
					{
						$this->session->set_flashdata('error',"Not Added sucessfully.");
						redirect('Emotions/edit_sol/'.$eid);
					}
				   else
					{
						$this->session->set_flashdata('error',"Sorry,try again!");
						redirect('Emotions/edit_sol/'.$eid);
					}
						
		   } 
		
		
		
		
		}



	
	
//------------------------------------------------------------------------------------------------------------------------------------------//			
}