<style>
    .panel-group .panel-heading + .panel-collapse > .panel-body {
  border: 1px solid #ddd;
}
.panel-group,
.panel-group .panel,
.panel-group .panel-heading,
.panel-group .panel-heading a,
.panel-group .panel-title,
.panel-group .panel-title a,
.panel-group .panel-body,
.panel-group .panel-group .panel-heading + .panel-collapse > .panel-body {
  border-radius: 2px;
  border: 0;
}
.panel-group .panel-heading {
  padding: 0;
}
.panel-group .panel-heading a {
  display: block;
  background: #668bb1;
  color: #ffffff;
  padding: 15px;
  text-decoration: none;
  position: relative;
}
.panel-group .panel-heading a.collapsed {
  background: #eeeeee;
  color: inherit;
}
.panel-group .panel-heading a:after {
  content: '-';
  position: absolute;
  right: 20px;
  top:5px;
  font-size:30px;
}
.panel-group .panel-heading a.collapsed:after {
  content: '+';
}
.panel-group .panel-collapse {
  margin-top: 5px !important;
}
.panel-group .panel-body {
  background: #ffffff;
  padding: 15px;
}
.panel-group .panel {
  background-color: transparent;
}
.panel-group .panel-body p:last-child,
.panel-group .panel-body ul:last-child,
.panel-group .panel-body ol:last-child {
  margin-bottom: 0;
}

    </style>

        <div id="page-wrapper">
            <div class="row">
            <div class="col-lg-12">
            <h1 class="page-header">Product</h1>
            </div>
            <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                        Add Products
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6" style="width:100%">
                                
                                 <?php 
								  if(isset($eid))
								  {
								  $post_url=base_url()."Product/update";	
								  }else{ 
								  $post_url=base_url()."Product/update";
								  }
								  ?>
    <div class="display_message" id="error_msgs"> 
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
         
         
                                  
                                  
         <?php echo "<div class=alert-danger>".validation_errors()."</div>"; ?>  
                               
        <form role="form" method="post" action="<?php echo $post_url;?>" enctype="multipart/form-data">
        
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">         
         
         
         <input type="hidden" id="eid" name="eid" value="<?php if(isset($eid)){echo $eid;}?>" />
         
       
         
                     
<!--       <div class="form-group">
         
           <select class="form-control" id="sel1" name="type" id="type" data-live-search="true">
          <option value=" ">Select Policy Type </option>
   
           <?php 
            foreach($policy as $data)
            {?>
          <option value=<?php echo $data['policy_id'] ?>> <?php echo $data['type'] ?></option>
                        
          <?php }
            
            ?>
          
           
      </select>
       </div>-->
<!--           <div class="form-group">
        <label>Name</label>
        <input class="form-control" placeholder="Enter Name" name="name" id="title" value="<?php if(isset($get_results)){echo $get_results['name'];}?><?php echo set_value('name'); ?>" required>
        </div>-->
<!--         <div class="form-group">
         <select class="form-control" id="sel1" name="insurer" id="insurer" data-live-search="true">
        <option value=" ">Select Insurer</option>
           <?php 
            foreach($insurer as $data)
            {?>
          <option value="<?php echo $data['insurer_id']?>"> <?php echo $data['name'] ?></option>
                        
           <?php }
            
            ?> 
      </select>
         </div>-->
        
<!--         <div class="form-group">
         <select class="form-control" id="sel1" name="insurer" id="insurer" data-live-search="true">
        <option value=" ">Select Insurer</option>
           <?php 
            foreach($products as $data)
            {?>
          <option value="<?php echo $data['product_id']?>"> <?php echo $data['product_name'] ?></option>
                        
           <?php }
            
            ?>
      </select>
         </div>-->

         <!--<div class="panel-group" id="accordion1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne">Collapsible Group Item #1
                        </a>
                    </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in">
                    <div class="panel-body">Panel 1</div>
                </div>
            </div>-->

         <!--Final nested accordion--> 
<!--            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion1" href="#collapseTwo">Select Policy Type
                        </a>
                    </h4>
                </div>
                <div id="collapseTwo" class="panel-collapse collapse">
                    <div class="panel-body">
                        <div class="panel-body">
                                          <?php 
                                foreach($policy as $data)
            {?>
                            <div class="panel-group" id="accordion21">
                  
                                <div class="panel">
                                    
            
                                    <a data-toggle="collapse" data-parent="#accordion21" href="#collapseTwoOne"><?php echo $data['type'] ?> &raquo;
                                    </a>
                  
                                    <div id="collapseTwoOne" class="panel-collapse collapse">
                                        <div class="panel-body"> <a data-toggle="collapse" data-parent="#accordion21" href="#collapseTwoTwo">HDFC &raquo;
                                    </a>
                                    </div>
                                      <div class="panel-body"> <a data-toggle="collapse" data-parent="#accordion21" href="#collapseTwoTwo">ICICI &raquo;
                                    </a>
                                    </div>
                                </div>
                                
                            </div>
                                                  
                        </div>
                            <?php }
            
            ?>
                    </div>
                </div>
            </div>
                </div>-->



<div class="container" style="width:100%">

         <div class="panel-group" id="accordion">
         <?php 
            foreach($policy as $data)
            {?>
            
            <div class="panel panel-default">
               <div class="panel-heading">
                  <h4 class="panel-title">
                     <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                     <?php echo $data['type'];?>
                     </a>
                  </h4>
               </div><!--/.panel-heading -->
               <div id="collapseTwo" class="panel-collapse collapse">
                  <div class="panel-body">

                    <!-- nested -->


         <div class="panel-group" id="nested">
         <?php 
            foreach($insurer as $data)
            {?>
            <div class="panel panel-default">
               <div class="panel-heading">
                  <h4 class="panel-title">
                     <a data-toggle="collapse" data-parent="#nested" href="#nested-collapseOne">
                     <?php echo $data['name'];?>
                     </a>
                  </h4>
               </div><!--/.panel-heading -->
               
               <div id="nested-collapseOne" class="panel-collapse collapse in">
                  <div class="panel-body">
                      
                      <div class="form-group">
                                    
            <select class="form-control" id="sel1" name="insurer" id="insurer" data-live-search="true">
        <option value=" ">Select product</option>
           <?php 
            foreach($products as $data)
            {?>
          <option value="<?php echo $data['product_id']?>"> <?php echo $data['product_name'] ?></option>
                        
        
      </select>
                      
                      </div>      
                      <div class="form-group">
      <input type="text" class="form-control" id="policy_holder" placeholder="Enter Base Rate(%)" name="policy_holder">
      </div>
                       <div class="form-group">
      <input type="text" class="form-control" id="policy_holder" placeholder="Enter Delta Rate(%)" name="policy_holder">
      </div>
                       <div class="form-group">
                           <label> Final Rate:
      <input type="text" class="form-control" id="policy_holder" name="policy_holder">
      <button  type="submit" value="submit" class="btn btn-default" >Save</button>
      </div><?php }?>
                  </div><!--/.panel-body -->
               </div><!--/.panel-collapse --> 
            </div><!-- /.panel --> 
            
            
            <?php } ?>

         </div><!-- /.panel-group -->


<!-- nested -->
                    
                     
                  </div><!--/.panel-body -->
               </div><!--/.panel-collapse -->
            </div><!-- /.panel -->
            <?php }?>
           
         </div><!-- /.panel-group -->

</div><!-- /.container -->  


        <button type="submit" class="btn btn-primary btn-lg btn-block" name="save_question" value="save">Save</button>
        </form>
                             
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    
