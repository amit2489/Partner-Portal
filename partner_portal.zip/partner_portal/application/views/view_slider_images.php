              <div id="page-wrapper">
              <div class="row">
              <div class="col-lg-12">
              <h1 class="page-header">View Slider Image</h1>
              
    <div class="display_message" id="error_msgs"> 
    <?php if(isset($error) && !empty($error)) { ?><div class="alert-danger"><?php echo $error; ?></div><?php } ?>
    <?php if(isset($sucess) && !empty($sucess)) { ?><div class="alert-success"><?php echo $sucess; ?></div><?php } ?>
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
              
              
              
              
              
              </div>
              <!-- /.col-lg-12 -->
              </div>
           
            
            
           
            
            
            <div class="row">
               
                    <div class="panel panel-default">
                        <div class="panel-heading"> View Slider Image</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                            
                            
                             <?php if(isset($get_results) && !empty($get_results) ){ ?>
                                <table class="table table-hover">
                                    <thead>
                                      <tr>
                                      <th colspan="20" id="pages"><?php //echo $links; ?></th>
                                      </tr>
   
                                    
                                    
                  <tr>
                      <th>ID</th>
                      <th>Image</th>
                      <th>Option</th>
                     </tr>
                                        
                                    </thead>
                                    <tbody>
                                    <?php 
									  $b = 0;
									  foreach($get_results as $data) {
									  $class = ($b++ % 2 == 0) ? 'even' : 'odd';
									  ?>
                                        <tr class="<?php echo $class; ?>">
                                            <td><?php echo $counter++; ?></td>
                                          <td><img src="<?php echo base_url();?>upload/<?php if(isset($data['name'])){ echo $data['name'];} ?>" style="width:150px; height:100px;"/></td>
     
          <td> <a href="<?php echo base_url();?>Delete/delete_slider_images/<?php echo $data['id'];?>/<?php echo $data['email'];?>"><span>Delete</span></a></td>                         
                                        </tr>
                                        <?php }?>
                                        <!--<tr>
                                            <td>2</td>
                                            <td>Jacob</td>
                                            <td>Thornton</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Larry</td>
                                            <td>the Bird</td>
                                            <td>@twitter</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>-->
                                    </tbody>
                                </table>
                                 <?php } else{ 
echo "No Data Available";}?>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              
                
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

  