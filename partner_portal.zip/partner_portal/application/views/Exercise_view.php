              <div id="page-wrapper">
              <div class="row">
              <div class="col-lg-12">
              <h3 class="page-header">Exercise</h3>
              
    <div class="display_message" id="error_msgs"> 
    <?php if(isset($error) && !empty($error)) { ?><div class="alert-danger"><?php echo $error; ?></div><?php } ?>
    <?php if(isset($sucess) && !empty($sucess)) { ?><div class="alert-success"><?php echo $sucess; ?></div><?php } ?>
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
     <?php echo "<div class=alert-danger>".validation_errors()."</div>"; ?>  
    </div>
              
              
              
              
              
              </div>
              <!-- /.col-lg-12 -->
              </div>
           
            
            
           
            
            
            <div class="row">
               
                    <div class="panel panel-default">
                        <div class="panel-heading">View Exercise Question</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                            
                            
                            
                             <?php if(isset($results) && !empty($results) ){ ?>
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                      <tr>
                                      <!--<th colspan="20" id="pages"><?php echo $links; ?></th>-->
                                      </tr>
   
                                    
                                    
                      <tr>
                      <th>ID</th>
                      <th>Category</th>
                      <th>Title</th>
                      <th>Days</th>
                      <th>Description</th>
                      <th>Percentage</th>
                      <th>Peer</th>
                      <th>Option</th>
                      </tr>
                                        
                                    </thead>
                                    <tbody>
                                    <?php 
									  $b = 0;
									  $i=0;
									  foreach($results as $data) 
									  {
										  $i++;
									  $class = ($b++ % 2 == 0) ? 'even' : 'odd';
									  ?>
                                            <tr class="<?php echo $class; ?>">
                                            <td><?php echo $counter++; ?></td>
                                            <?php $eid=$data['Exercise_id']; ?>
                                            <td>
                                            <?php  $cid=$data['cat_id']; 
                                          $query3=$this->db->query("SELECT * from category where cat_id='$cid'");
                                           foreach($query3->result_array()  as $row)
					   {
                                               echo $row['cat_name'];
                                             }
                                            ?></td>
                                            <td><?php echo $data['Title']; ?></td>
                                            <td><?php echo $data['days']; ?></td>
                                            <td><?php echo $data['Ex_desc']; ?></td>
               <td>
               <?php 
               $query=$this->db->query("select count(*) as abc from exercise_log where ex_id='$eid' ");
			   foreach($query->result_array()  as $rows)
					 {
						
				    $query1=$this->db->query("SELECT COUNT(DISTINCT email) as user from exercise_log");
					foreach($query1->result_array()  as $row)
					 {
						$abc =$rows['abc'];
						$totalWidth =$row['user'];
						
						//$new_width = ($abc / 100) * $totalWidth;
					        $new_width =($abc/$totalWidth) * 100;
						echo round($new_width);
						
						}
						}
			   ?>
               </td>                          
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
            <td>
            <label for="chkPassport123<?php echo $i;?>">
            <input type="checkbox" id="chkPassport<?php echo $i;?>" onclick="ShowHideDiv(this,'dvPassport<?php echo $i;?>')" />
            Do you want to increase Percentage?</label>
            <hr/>
           <div id="dvPassport<?php echo $i;?>" style="display: none">
              <form action="<?php echo base_url();?>Exercise/percent" method="post" >
              
              <input type="hidden" id="eid" name="eid" value="<?php if(isset($eid)){echo $eid;}?>" />
              
              Number:<input type="text" id="txtPassportNumber" name="txtPassportNumber" placeholder="Enter %" value="<?php if(isset($data)){ echo $data['peer'];}?>"/>
                     <input type="submit" id="txt" onclick="myFunction1()" />
                     
              </form>
           </div>
           </td>
                                            
                                              
                                             
<td>
<a href="<?php echo base_url();?>Exercise/edit/<?php echo $data['Exercise_id']; ?>" ><span>Edit</span></a> 
<a href="<?php echo base_url();?>Delete/delete_exercise/<?php echo $data['Exercise_id'];?>" onclick="return myFunction();"><span>Delete</span></a>
</td>
                                            
                      
                                            
                                            
                                        </tr>
                                        <?php }?>
                                        <!--<tr>
                                            <td>2</td>
                                            <td>Jacob</td>
                                            <td>Thornton</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Larry</td>
                                            <td>the Bird</td>
                                            <td>@twitter</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>-->
                                    </tbody>
                                </table>
                                 <?php } else{}?>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              
                
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

  
 <script>
  function myFunction()
	{
	var r =confirm("Are you sure want to Delete!");
	
	if (r == true) {
			location.reload();
	//event.preventDefault();

	} else {
	event.preventDefault();
	location.reload();
	}
	}
  
  </script>    
  
   <script>
  function myFunction1()
	{
	var r =confirm("Are you sure want to percentage!");
	
	if (r == true) {
			location.reload();
	//event.preventDefault();

	} else {
	event.preventDefault();
	location.reload();
	}
	}
  
  </script>                                              <script type="text/javascript">
											  
                                              function ShowHideDiv(id,tb) {
												  
                                              var dvPassport = document.getElementById(tb);
											 
                                             
											 dvPassport.style.display = id.checked ? "block" : "none";
											 
											 
                                              }
                                             </script>
  <!--<script type="text/javascript">
    function ShowHideDiv(chkPassport) {
		alert(chkPassport.checked);
        var dvPassport = document.getElementById("dvPassport");
        dvPassport.style.display = chkPassport.checked ? "block" : "none";
    }
</script>-->