        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Exercise</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add Exercise Question
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6" style="width:100%">
                                
                                 <?php 
								  if(isset($eid))
								  {
								  $post_url=base_url()."Exercise/update";	
								  }else{ 
								  $post_url=base_url()."Exercise/Add";
								  }
								  ?>
    <div class="display_message" id="error_msgs"> 
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
         
         
                                  
                                  
         <?php echo "<div class=alert-danger>".validation_errors()."</div>"; ?>  
                               
        <form role="form" method="post" action="<?php echo $post_url;?>" enctype="multipart/form-data">
        
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">         
         
         
         <input type="hidden" id="eid" name="eid" value="<?php if(isset($eid)){echo $eid;}?>" />
        
        
        <div class="form-group">
        <label>Selects Option</label>
        <select class="form-control" name="Option" id="Option" required>
            <option value="">Selects </option>
            <option value="1">Mind conditioning</option>
            <option value="2">Gratitude & Reflection</option>
            <option value="3">Rejuvenation</option>
        </select>
        </div> 





        <div class="form-group">
        <label>Selects Days</label>
        <select class="form-control" name="days" id="days" required>
            <!--<option value="">Select Days</option>-->
            
            <?php if(isset($days))
			    {
				foreach($days as $cat)
				
				{?>
         <option value="<?php echo $cat['days_id'];?>"><?php echo $cat['days']; ?></option>
                  
             <?php
				}
				}
			?>
            
            
            
        </select>
        </div>
        
        
        
        
        
        
        
         
                                        
        <div class="form-group">
        <label>Title</label>
        <input class="form-control" placeholder="Enter Title" name="title" id="title" value="<?php if(isset($get_results)){echo $get_results['Title'];}?><?php echo set_value('Title'); ?>" required>
         
        </div>
                    
       <div class="form-group">
       <label>Description</label>
       <textarea class="form-control" rows="5" name="description" id="description" value="" ><?php if(isset($get_results)){echo $get_results['Ex_desc'];}?><?php echo set_value('Ex_desc'); ?></textarea>
       <script>
		CKEDITOR.replace( 'description', {
        filebrowserUploadUrl: "<?php echo base_url(); ?>upload/upload.php" } );
	   </script>
        </div>
        
       
       
       
         <div class="form-group">
        <label>Add Answer</label>
        <input type='button' value='Add Option' id='addButton'>
        <input type='button' value='Remove Option' id='removeButton'>
        
        <div id='TextBoxesGroup'>
         <div id="TextBoxDiv1">
         
       <!-- <label>Fill in the Blanks #1 : </label><input type='textbox' class="input-long" name="pollopt[]" id='textbox1' value="">
               
               <select name="dropdwn[]" id="dropdwn">
               <option value="True">True</option>
               <option value="False">False</option>
               </select>
               
               <select name="dropdown[]" id="dropdown">
               <option value="Date">Date</option>
               <option value="Time">Time</option>
                <option value="Text">Text</option>
               </select>-->
               
               </div>
        </div>
        
        
        
        </div>
       
       
       
        <!--<div class="form-group">
        <label>Fill in the Blanks</label>
        <input class="form-control" placeholder="Fill in the Blanks" name="title" id="title" value="<?php if(isset($get_results)){echo $get_results['Title'];}?><?php echo set_value('Title'); ?>" required>
        </div>
       
       
        <div class="form-group">
        <label>Selects Option</label>
        <select class="form-control" name="Option" id="Option" required>
            <option value="">Selects Option</option>
            <option value="1">True</option>
            <option value="2">False</option>
        </select>
        </div> 
        
         <div class="form-group">
        <label>Selects Type</label>
        <select class="form-control" name="type" id="type" required>
            <option value="">Selects Type</option>
            <option value="Date">Date</option>
            <option value="Time">Time</option>
            <option value="Text">Text</option>
        </select>
        </div> 
       -->
       
       
       
       
       
       
       
       
       
       
        
        <button type="submit" class="btn btn-primary btn-lg btn-block" name="save_question" value="save">Save</button>
        </form>
                             
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    <script>
function add_poll_option()
{
	var counter1=parseInt(document.getElementById("counter").value);
	alert(counter1);
	var mydiv=document.getElementById("myDiv");
	var a = mydiv.innerHTML;
	a +='<label><b style="color:#ffb100;">Option '+counter1+'</b></label><br>';
	a += '<input type="text"  name="duration[]"  value="" ><br><br>';   
	mydiv.innerHTML = a;
    mydiv.appendChild(mydiv);
	alert(counter1);
	counter1=counter1+1;
	alert(counter1);
	document.getElementById("counter").value=counter1;
}
</script>

<script type="text/javascript">
 
$(document).ready(function(){
 
    var counter = 1;
 
    $("#addButton").click(function () {
 
	if(counter>10){
            alert("Only 10 Options allow");
            return false;
	}   
 
	var newTextBoxDiv = $(document.createElement('div'))
	     .attr("id", 'TextBoxDiv' + counter);
 
	newTextBoxDiv.after().html('<label>Fill in the Blanks #'+ counter + ' : </label>' +
	      '<input type="text" class="input-long" name="pollopt[]" id="textbox' + counter + '" value="" required>'+' <select name="dropdwn[]" id="dropdwn"><option value="1">True</option><option value="2">False</option></select>'+' <select name="dropdown[]" id="dropdown"><option value="Date">Date</option><option value="Time">Time</option><option value="Text">Text</option></select> ');
 
	newTextBoxDiv.appendTo("#TextBoxesGroup");
 
 
	counter++;
     });
 
     $("#removeButton").click(function () {
	if(counter==1){
          alert("No more Option to remove");
          return false;
       }   
 
	counter--;
 
        $("#TextBoxDiv" + counter).remove();
 
     });
 
     $("#getButtonValue").click(function () {
 
	var msg = '';
	for(i=0; i<counter; i++){
   	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
	}
    	  alert(msg);
     });
  });
</script>  
