<div id="page-wrapper">
              <div class="row">
              <div class="col-lg-12">
              <h3 class="page-header">Agent Details</h3>
              
    <div class="display_message" id="error_msgs"> 
    <?php if(isset($error) && !empty($error)) { ?><div class="alert-danger"><?php echo $error; ?></div><?php } ?>
    <?php if(isset($sucess) && !empty($sucess)) { ?><div class="alert-success"><?php echo $sucess; ?></div><?php } ?>
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
              
              
              
              
              
              </div>
              <!-- /.col-lg-12 -->
              </div>
           
            
            
           
            
            
            <div class="row">
               
                    <div class="panel panel-default">
                        <div class="panel-heading"> View User Details</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                            
                            <!--<form action="<?php echo base_url();?>Change_status/user_status" method="post" />-->     
                         
                            <!--<input type="submit" class="btn-info" name="s1" value="Change Status" class="submit-gray" /> -->
                            
                             <?php if(isset($results) && !empty($results) ){ ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                      <tr>
                                      <th colspan="20" id="pages"><?php echo $links; ?></th>
                                      </tr>
   
                                    
                                    
                  <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Age</th>
                      <th>Weigth</th>
                      <th>Heigth</th>
                      <th>Start Date</th>
                      <th>Days</th>
                      <th>Status</th>
                      <!--<th><input type="checkbox" name="chkall" id="chkall" onchange="myFunction()" value="A" />Status</th>-->
                     <th>option</th>
                     </tr>
                                        
                                    </thead>
                                    <tbody>
                                    <?php 
									  $b = 0;
									  foreach($results as $data) {
									  $class = ($b++ % 2 == 0) ? 'even' : 'odd';
									  ?>
                                        <tr class="<?php echo $class; ?>">
                                            <td><?php echo $counter++; ?></td>
                                            <td><?php echo $data['name']; ?></td>
                                            <td><?php echo $data['email']; ?></td>
                                            <td><?php echo $data['age']; ?></td>
                                            <td><?php echo $data['weigth']; ?></td>
                                            <td><?php echo $data['heigth']; ?></td>
                                            <!--<td><?php echo $data['start_date'];?></td>-->
                                             <td><?php if($data['start_date']==0000-00-00)
                                                 {
                                                 echo "Date Not Set";}
                                                 else 
                                                 {
                                                 echo $data['start_date'];
                                                 };?>
                                             </td>




                                            <td><?php  
                                             
                                             if($data['start_date']==0000-00-00)
                                             {echo 0;}
                                             else {
                                             $your_date = strtotime($data['start_date']);
                                             $now = time(); // or your date as well
                                             $datediff = $now - $your_date;
                                             $days=floor($datediff/(60*60*24));
                                             
                                            if($days >=40)
					    {
						echo "course over";
					    }
					    else
					    {
					       echo $days; 
					    }
											  
											  
                                            





                                              }
                                              ?>

                                            </td>


                                            <td><?php if($data['status']==1)
                                                 {
                                                 echo "Active";}
                                                 else if($data['status']==0)
                                                 {
                                                 echo "Inactive";
                                                 };?>
                                             </td>
          <!--<td><input type="checkbox" name="excel[]" class="chk" value="<?php echo $data['reg_id'];?>" /></form></td> -->   
          <td> 
          <a href="<?php echo base_url();?>Register/edit/<?php echo $data['reg_id'];?>"><span>Edit</span></a>
          <a href="<?php echo base_url();?>Delete/delete_reg/<?php echo $data['reg_id'];?>"><span>Delete</span></a>
          
          </td>                         
                                        </tr>
                                        <?php }?>
                                        <!--<tr>
                                            <td>2</td>
                                            <td>Jacob</td>
                                            <td>Thornton</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Larry</td>
                                            <td>the Bird</td>
                                            <td>@twitter</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>-->
                                    </tbody>
                                </table>
                                 <?php } else{}?>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              
                
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

   <script>
function myFunction() 
{
//alert(document.getElementsByName("chk")[0]);

var x=document.getElementsByClassName("chk");
	//alert(x.length);
if (document.getElementById("chkall").checked== true)
{
	
	for(i=0; i<x.length; i++)
	{
	  
	  x[i].checked= true;
	 // x[i].disabled = true;
	   
	}
}

else
{
  for(i=0; i<x.length; i++)
	{
	  
	  x[i].checked= false;
	 // x[i].disabled = true;
	   
	}

}
}
</script>

