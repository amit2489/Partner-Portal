<?php if(isset($get_table) && !empty($get_table) ){ ?>
                                <table class="table table-hover">
                                    <thead>
                                      <tr>
                                      <th colspan="20" id="pages"><?php //echo $links; ?></th>
                                      </tr>
   
                                    
                                    
                  <tr>
                      <th>ID</th>
                      <th>Username</th>
                      <th>Email</th>
<th>Total Images</th>
                      <th>Option</th>

                     </tr>
                                        
                                    </thead>
                                    <tbody>
                                    <?php 
									  $b = 0;
									  foreach($get_table as $data) {
									  $class = ($b++ % 2 == 0) ? 'even' : 'odd';
									  ?>
                                        <tr class="<?php echo $class; ?>">
                                            <td><?php echo $b ?></td>
                                            <td><?php echo $data['name']; ?></td>
                                            <td><?php echo $data['email']; ?></td>
                                          <td><?php
$sql=$this->db->query("SELECT count(image)as img FROM `vision_board` where email='".$data['email']."'");
foreach($sql->result_array() as $rows)
{
$images=$rows['img'];
if($images >0)
{
echo $images;
}else if($images <1)
{
echo "No Images";
}
}
?>
</td> 
                                            
            
          <td> <a href="<?php echo base_url();?>Visionboard/view_img/<?php echo $data['email']; ?>"><span>View</span></a></td>                         
                                        </tr>
                                        <?php }?>
                                        <!--<tr>
                                            <td>2</td>
                                            <td>Jacob</td>
                                            <td>Thornton</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Larry</td>
                                            <td>the Bird</td>
                                            <td>@twitter</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>-->
                                    </tbody>
                                </table>
                                 <?php } else{}?>