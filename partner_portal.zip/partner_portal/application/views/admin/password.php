        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Change Password</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Change Password
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6" style="width:100%">
                                
                                 <?php 
								  if(isset($eid))
								  {
								  $post_url=base_url()."Password/change";	
								  }else{ 
								  $post_url=base_url()."Password/change";
								  }
								  ?>
    <div class="display_message" id="error_msgs"> 
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
         
         
                                  
                                  
         <?php echo "<div class=alert-danger>".validation_errors()."</div>"; ?>  
                               
        <form role="form" method="post" action="<?php echo $post_url;?>" enctype="multipart/form-data">
        
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">         
         
         
         <input type="hidden" id="eid" name="eid" value="<?php if(isset($eid)){echo $eid;}?>" />
         
          
        <div class="form-group">
        <label>Email</label>
        <input class="form-control" placeholder="Enter Your Email" name="email" id="email" value="<?php $user_id=$this->session->userdata['upter_admin']['id'];
$query=$this->db->query("select * from login where id='".$user_id."'");

foreach($query->result_array() as $row)
{
echo $row['email'];
}
 ?>" readonly>
        </div> 

<div class="form-group">
        <label>Old Password</label>
        <input class="form-control" placeholder="Enter Your Old Password" name="old_pass" id="old_pass" value="<?php if(isset($get_results)){echo $get_results['title'];}?><?php echo set_value('old_pass'); ?>" >
        </div>  

<div class="form-group">
        <label>New Password</label>
        <input class="form-control" placeholder="Enter Your New Password" name="new_pass" id="new_pass" value="<?php if(isset($get_results)){echo $get_results['title'];}?><?php echo set_value('new_pass'); ?>" >
        </div>

<div class="form-group">
        <label>Confirm Password</label>
        <input class="form-control" placeholder="Confirm Your Above Password" name="con_pass" id="con_pass" value="<?php if(isset($get_results)){echo $get_results['title'];}?><?php echo set_value('con_pass'); ?>" >
        </div>
          
          
          
          
                                       
        
                    
       
      
       
        
        
        
        
                
        <button type="submit" class="btn btn-primary btn-lg btn-block" name="save_question" value="save">Save</button>
        </form>
                             
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    