            
            <!-- /.navbar-static-side -->
        </nav>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
            
                <div class="row">
                    <div class="col-lg-12">
                    <h1 class="page-header">Welcome Admin</h1>
                    </div>
               
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
             <!------------------------------------------------------------------------------------>
          <div class="display_message" id="error_msgs"> 
         <?php if($this->session->flashdata('sucesslogin')){echo "<div class=alert-success>".$this->session->flashdata('sucesslogin')."</div>";}
	     ?>
         </div>
          <!------------------------------------------------------------>   
        </div>
        <!-- /#page-wrapper -->

   
