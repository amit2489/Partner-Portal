        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Emotions</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Basic Form Elements
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6" style="width:100%">
                                
                                 <?php 
								  if(isset($eid))
								  {
								  $post_url=base_url()."Emotions/update";	
								  }else{ 
								  $post_url=base_url()."Emotions/update";
								  }
								  ?>
    <div class="display_message" id="error_msgs"> 
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
         
         
                                  
                                  
         <?php echo "<div class=alert-danger>".validation_errors()."</div>"; ?>  
                               
        <form role="form" method="post" action="<?php echo $post_url;?>" enctype="multipart/form-data">
        
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">         
         
         
         <input type="hidden" id="eid" name="eid" value="<?php if(isset($eid)){echo $eid;}?>" />
         
          
        <div class="form-group">
<label>Selects Emotions</label>
<select class="form-control" name="days" id="days" required>
<option value="">Select Emotions</option>
<?php if(isset($emcat))
{
foreach($emcat as $cat)
{?>
<!--<option value="<?php echo $cat['em_cat_name'];?>"><?php echo $cat['em_cat_name']; ?></option>-->


 <option value="<?php echo $cat['em_cat_id'];?>" <?php if(isset($get_results) && $get_results['em_cat_id'] == $cat['em_cat_id'] )
   {echo "selected";}else{} ?>><?php echo $cat['em_cat_name']; ?></option>
    <?php }}?>



<?php //}} ?>
            
</select>
</div>  
          
          
          
          
                                       
<div class="form-group">
<label>Title</label>
<input class="form-control" placeholder="Enter Title" name="title" id="title" value="<?php if(isset($get_results)){echo $get_results['em_title'];}?><?php echo set_value('em_title'); ?>" required>
</div>
                    
       
      
        <div class="form-group">
    <label> Description</label>
    <textarea class="form-control" rows="5" name="question" id="question" value="" ><?php if(isset($get_results)){echo $get_results['em_desc'];}?><?php echo set_value('em_desc'); ?></textarea>
    <script>
	CKEDITOR.replace( 'question', {
    filebrowserUploadUrl: "<?php echo base_url(); ?>upload/upload.php" } );
	</script>
    </div>
        
        
        
        <tr>
<td><label>Last Inserted Option</label></td>
<td> 
<?php if(isset($result) && !empty($result) ){ ?>
 <table class="table table-hover">
     
          <thead>
        <tr>
          <th colspan="10" id="pages"><?php echo $links; ?></th>
        </tr>
        
         <tr>   
         <th>No</th>
         <th>Question</th>
         <th>Delete</th>
         </tr>
        </thead>
        
       <tbody>
        <?php 
		$b = 0;
		foreach($result as $data) {
		$class = ($b++ % 2 == 0) ? 'even' : 'odd';
		?>
          <tr class="<?php echo $class; ?>">
          <td><?php echo $b; ?></td>
          <td><?php echo $data['em_des_option'];?></td>
         
         
          
         
         
         
          <td>
         
           
  
     <a href="<?php echo base_url();?>Delete/delete_option_em/<?php echo $data['em_option_id'];?>/<?php echo $eid;?>"><span>Delete</span></a>
     </td>
     </tr>
     <?php }?>
     </tbody>
     </table>       
     <?php } else{}?>
     <tr>

        
        
        
        
        
        
        
        
        
        
        <div class="form-group">
        <label>Add Answer</label>
        <input type='button' value='Add Option' id='addButton'>
        <input type='button' value='Remove Option' id='removeButton'>
        
        <div id='TextBoxesGroup'>
               <div id="TextBoxDiv1">
               <!--<label>Option #1 : </label><input type='textbox' class="input-long" name="pollopt[]" id='textbox1' value="">
               <select name="dropdwn[]" id="dropdwn">
               <option value="1">correct</option>
               <option value="2">wrong</option>
               </select>-->
               </div>
       </div>
        </div>
        
        
        
        
        
                
        <button type="submit" class="btn btn-primary btn-lg btn-block" name="save_question" value="save">Save</button>
        </form>
                             
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    <script>
function add_poll_option()
{
	var counter1=parseInt(document.getElementById("counter").value);
	alert(counter1);
	var mydiv=document.getElementById("myDiv");
	var a = mydiv.innerHTML;
	a +='<label><b style="color:#ffb100;">Option '+counter1+'</b></label><br>';
	a += '<input type="text"  name="duration[]"  value="" ><br><br>';   
	mydiv.innerHTML = a;
    mydiv.appendChild(mydiv);
	alert(counter1);
	counter1=counter1+1;
	alert(counter1);
	document.getElementById("counter").value=counter1;
}
</script>

<script type="text/javascript">
 
$(document).ready(function(){
 
    var counter = 1;
 
    $("#addButton").click(function () {
 
	if(counter>10)
	{
            alert("Only 10 Options allow");
            return false;
	}   
 
	var newTextBoxDiv = $(document.createElement('div'))
	.attr("id", 'TextBoxDiv' + counter);
 
	newTextBoxDiv.after().html('<label>Title #'+ counter + ' : </label>' +
    '<input type="text" class="form-control" name="pollopt[]" id="textbox' + counter + '" value="" required>');
 
	newTextBoxDiv.appendTo("#TextBoxesGroup");
 
 
	counter++;
     });
 
     $("#removeButton").click(function () {
	if(counter==1){
          alert("No more Option to remove");
          return false;
       }   
 
	counter--;
 
        $("#TextBoxDiv" + counter).remove();
 
     });
 
     $("#getButtonValue").click(function () {
 
	var msg = '';
	for(i=0; i<counter; i++){
   	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
	}
    	  alert(msg);
     });
  });
</script>