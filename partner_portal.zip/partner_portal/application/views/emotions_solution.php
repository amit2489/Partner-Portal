        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Emotions Mgmt</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          Add Emotions Solutions
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6" style="width:100%">
                                
                                 <?php 
								  if(isset($eid))
								  {
								  $post_url=base_url()."Emotions/solution_update";	
								  }else{ 
								  $post_url=base_url()."Emotions/solution_add";
								  }
								  ?>
    <div class="display_message" id="error_msgs"> 
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
         
         
                                  
                                  
<?php echo "<div class=alert-danger>".validation_errors()."</div>"; ?>  
<form role="form" method="post" action="<?php echo $post_url;?>" enctype="multipart/form-data">
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">         

<input type="hidden" id="eid" name="eid" value="<?php if(isset($eid)){echo $eid;}?>" />
         
<div class="form-group">
<label>Selects Emotions</label>
<select class="form-control" name="days" id="days" required>
<option value="">Select Emotions</option>
<?php if(isset($emcat))
{
foreach($emcat as $cat)
{?>
<!--<option value="<?php echo $cat['em_cat_name'];?>"><?php echo $cat['em_cat_name']; ?></option>-->


 <option value="<?php echo $cat['em_cat_id'];?>" <?php if(isset($get_results) && $get_results['em_cat_id'] == $cat['em_cat_id'] )
   {echo "selected";}else{} ?>><?php echo $cat['em_cat_name']; ?></option>
    <?php }}?>



<?php //}} ?>
            
</select>
</div>  
          
          
          
          
                                       
    <div class="form-group">
    <label>Title</label>
    <input class="form-control" placeholder="Enter Title" name="title" id="title" value="<?php if(isset($get_results)){echo $get_results['title'];}?><?php echo set_value('title'); ?>" required>
    </div>
                    
     
    
      
    
      
      
    <div class="form-group">
    <label> Description</label>
    <textarea class="form-control" rows="5" name="question" id="question" value="" ><?php if(isset($get_results)){echo $get_results['description'];}?><?php echo set_value('description'); ?></textarea>
    <script>
	CKEDITOR.replace( 'question', {
    filebrowserUploadUrl: "<?php echo base_url(); ?>upload/upload.php" } );
	</script>
    </div>
        
        
      
        
        
        
        
        
                
        <button type="submit" class="btn btn-primary btn-lg btn-block" name="save_question" value="save">Save</button>
        </form>
                             
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

   