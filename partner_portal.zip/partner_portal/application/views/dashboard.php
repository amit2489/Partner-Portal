        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <p> </p>
<!--                    <h1 class="page-header"></h1>-->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <a href="<?php echo base_url();?>Agent/view">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                
                   <?php  $quer=$this->db->query("SELECT COUNT(agent_id) as id FROM d_agent");
					if(isset($quer) && $quer!="")
		            {
			  		foreach($quer->result_array()  as $rows)
					{
					?>
                                    <div class="huge"><?php echo $rows['id'];?></div>
                               <?php }}?>       
                                    <div>Number of Partners!</div>
                                </div>
                            </div>
                        </div>
                        
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        
                    </div>
                </div>
                </a>
                
                <a href="<?php echo base_url();?>Uploaded_policy/view">
                 <div class="col-lg-3 col-md-6" >
                    <div class="panel panel-primary" >
                        <div class="panel-heading" style="background-color:#e68a00">
                            <div class="row" >
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                
                   <?php  $quer=$this->db->query("SELECT COUNT(policy) as id FROM d_uploaded_policy");
					if(isset($quer) && $quer!="")
		            {
			  		foreach($quer->result_array()  as $rows)
					{
					?>
                                    <div class="huge"><?php echo $rows['id'];?></div>
                               <?php }}?>       
                                    <div>Uploaded Policies!</div>
                                </div>
                            </div>
                        </div>
                        
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        
                    </div>
                </div>
                    </a>
                
                
                
                <a href="<?php echo base_url();?>Insurer/view">
                 <div class="col-lg-3 col-md-6" >
                    <div class="panel panel-primary" >
                        <div class="panel-heading" style="background-color:#cc2900">
                            <div class="row" >
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                
                   <?php  $quer=$this->db->query("SELECT COUNT(insurer_id) as id FROM d_insurer");
					if(isset($quer) && $quer!="")
		            {
			  		foreach($quer->result_array()  as $rows)
					{
					?>
                                    <div class="huge"><?php echo $rows['id'];?></div>
                               <?php }}?>       
                                    <div>Number of Insurers!</div>
                                </div>
                            </div>
                        </div>
                        
                            <div class="panel-footer">
                                <span class="pull-left">View Insurer List</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        
                    </div>
                </div>
                    </a>
                
                
                
                 <a href="<?php echo base_url();?>Policy/Report">
                 <div class="col-lg-3 col-md-6" >
                    <div class="panel panel-primary" >
                        <div class="panel-heading" style="background-color:#009933">
                            <div class="row" >
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                
                                    <?php  $quer=$this->db->query("SELECT COUNT(policy) as id FROM d_uploaded_policy");
					if(isset($quer) && $quer!="")
		            {
			  		foreach($quer->result_array()  as $rows)
					{
					?>
                                    <div class="huge"><?php echo $rows['id'];?></div>
                               <?php }}?>       
                                    <div>Total Policies!</div>
                   
                                </div>
                            </div>
                        </div>
                        
                            <div class="panel-footer">
                                <span class="pull-left">Policy Type Report</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        
                    </div>
                </div>
                    </a>
                
                
                
                
                
                 
                
                
                 <a href="<?php echo base_url();?>Insurer/report">
                 <div class="col-lg-3 col-md-6" >
                    <div class="panel panel-primary" >
                        <div class="panel-heading" style="background-color:#ac7339">
                            <div class="row" >
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
<!--                                <div class="col-xs-9 text-right">
                                
                  
                                    <div>Insurer-wise Report</div>
                                </div>-->
                            </div>
                        </div>
                        
                            <div class="panel-footer">
                                <span class="pull-left">Insurer-wise Report</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        
                    </div>
                </div>
                    </a>

                
                
                

                <!--<div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">12</div>
                                    <div>New Tasks!</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>-->
                <!--<div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-shopping-cart fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">124</div>
                                    <div>New Orders!</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>-->
                <!--<div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">13</div>
                                    <div>Support Tickets!</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>-->
           
        </div>
        <!-- /#page-wrapper -->

   