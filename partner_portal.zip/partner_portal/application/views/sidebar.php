<div class="navbar-default sidebar" role="navigation">


<?php 
	if(isset($admin) && !empty($admin))
	{
	
	if(isset($admin["Home"])){$Home=$admin["Home"];}

	if(isset($admin["Rg_user"])){$Rg_user=$admin["Rg_user"];}

	if(isset($admin["Insurer"])){$Insurer=$admin["Insurer"];}

	if(isset($admin["Policy"])){$Policy=$admin["Policy"];}
        
        if(isset($admin["Uploaded_policy"])){$Uploaded_policy=$admin["Uploaded_policy"];}

	if(isset($admin["Upload"])){$Belief=$admin["Upload"];}
        
        if(isset($admin["Slider_images"])){$Slider_images=$admin["Slider_images"];}
        
        if(isset($admin["Insurer_policy"])){$Insurer_policy=$admin["Insurer_policy"];}
        
        if(isset($admin["Policy_report"])){$Policy_report=$admin["Policy_report"];}

	//if(isset($admin["Exercise"])){$Exercise=$admin["Exercise"];}

       // if(isset($admin["company"])){$company=$admin["company"];}

	//if(isset($admin["Coach"])){$Coach=$admin["Coach"];}

        //if(isset($admin["emotion"])){$emotion=$admin["emotion"];}

        //if(isset($admin["tips"])){$tips=$admin["tips"];}
	
	}
   
   ?>
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                      
                      <!-- <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            
                        </li>-->
                        
                    
                        
                         <?php if(isset($Home) && !empty($Home)){ ?>
                        <li><a href='#'><i class="fa fa-dashboard fa-fw"></i> HOME<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Home as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>	
                        
                        
                        
                       
                         
                         
                         <?php if(isset($Rg_user) && !empty($Rg_user)){ ?>
                        <li><a href='#'><i class="fa fa-edit fa-fw"></i> PARTNER PROFILE<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Rg_user as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>	
                         
                         
                         <?php if(isset($Insurer) && !empty($Insurer)){ ?>
                        <li><a href='#'><i class="fa fa-edit fa-fw"></i> INSURER <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Insurer as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?> 
                        
                   
						
			<?php if(isset($Policy) && !empty($Policy)){ ?>
                        <li><a href='#'><i class="fa fa-edit fa-fw"></i> POLICY DETAILS<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Policy as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>
                        
                        
                        
                        <?php if(isset($Uploaded_policy) && !empty($Uploaded_policy)){ ?>
                        <li><a href='#'><i class="fa fa-edit fa-fw"></i> UPLOADED POLICY <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Uploaded_policy as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>
                        
                         <?php if(isset($Slider_images) && !empty($Slider_images)){ ?>
                        <li><a href='#'><i class="fa fa-edit fa-fw"></i> SLIDER IMAGES<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Slider_images as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>


                        <?php if(isset($Insurer_policy) && !empty($Insurer_policy)){ ?>
                        <li><a href='#'><i class="fa fa-edit fa-fw"></i> INSURER-WISE REPORT<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Insurer_policy as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>      
                         
                        
                        
                        <?php if(isset($Policy_report) && !empty($Policy_report)){ ?>
                        <li><a href='#'><i class="fa fa-edit fa-fw"></i> POLICY TYPE-WISE REPORT<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <?php foreach($Policy_report as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>  
                        
                        

                        <?php if(isset($Exercise) && !empty($Exercise)){ ?>
                        <li><a href='#'><i class="fa fa-dashboard fa-fw"></i>Exercise</a>
                        <ul>
                        <?php foreach($Exercise as $k=>$vall){?>
                        <li><a href='<?php echo base_url().$vall; ?>'><span><?php echo $k;?></span></a></li>
                        <?php } ?>
                        </ul>
                        </li>
                        <?php } else{} ?>	
	
                        

                         
                        


                      








                        <!--<li>
                        <a href="#"><i class="fa fa-table fa-fw"></i> Manage Profile</a>
                        </li>
                        -->
                       <!-- <li>
                        <a href="#"><i class="fa fa-edit fa-fw"></i> Forms</a>
                        </li>-->
                        
                        <!--<li>
                        <a href="#"><i class="fa fa-wrench fa-fw"></i> UI Elements<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <li>
                        <a href="panels-wells.html">Panels and Wells</a>
                        </li>
                        <li>
                        <a href="buttons.html">Buttons</a>
                        </li>
                        <li>
                        <a href="notifications.html">Notifications</a>
                        </li>
                        <li>
                        <a href="typography.html">Typography</a>
                        </li>
                        <li>
                        <a href="icons.html"> Icons</a>
                        </li>
                        <li>
                        <a href="grid.html">Grid</a>
                        </li>
                        </ul>
                            <!-- /.nav-second-level -->
                        <!--</li>-->
                        
                        
                        <!--<li>
                        <a href="#"><i class="fa fa-sitemap fa-fw"></i> Multi-Level Dropdown<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                        <li>
                        <a href="#">Second Level Item</a>
                        </li>
                        <li>
                        <a href="#">Second Level Item</a>
                        </li>
                        <li>
                        <a href="#">Third Level <span class="fa arrow"></span></a>
                        <ul class="nav nav-third-level">
                        <li>
                            <a href="#">Third Level Item</a>
                        </li>
                        <li>
                            <a href="#">Third Level Item</a>
                        </li>
                        <li>
                            <a href="#">Third Level Item</a>
                        </li>
                        <li>
                            <a href="#">Third Level Item</a>
                        </li>
                        </ul>
                                    <!-- /.nav-third-level -->
                           <!-- </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        <!--</li>-->
                        
                        <!--<li class="active">
                        <a href="#"><i class="fa fa-files-o fa-fw"></i> Sample Pages<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a class="active" href="blank.html">Blank Page</a>
                                </li>
                                <li>
                                    <a href="login.html">Login Page</a>
                                </li>
                                 <li>
                                    <a href="<?php echo base_url();?>Welcome/form">Form</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        <!--</li>-->
                        
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            
              <!-- /.navbar-static-side -->
        </nav>
        