<html>
<head>
<link href="<?php echo base_url(); ?>resouces/css/dropzone.css" type="text/css" rel="stylesheet" />
<script src="<?php echo base_url(); ?>resouces/dropzone.min.js"></script>
</head>
<body>
<form action="<?php echo site_url('/dropzone/upload'); ?>" class="dropzone"  >
</form>
</body>
</html>
