 <script>

 function showUsers() 
 {
	 //alert(1);
	var svalue=document.getElementById("svalue").value;
	
     if (svalue == "") {
        document.getElementById("getdata").innerHTML = "";
		 $("#abc").show();
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("getdata").innerHTML = xmlhttp.responseText;
				  $("#abc").hide();
            }
        };
		//alert(svalue);
       xmlhttp.open("GET","<?php echo base_url();?>SearchData/search?q="+svalue,true);
        xmlhttp.send();
    }
}
</script>

              <div id="page-wrapper">
              <div class="row">
              <div class="col-lg-12">
              <h3 class="page-header">Visionboard Images</h3>
              
    <div class="display_message" id="error_msgs"> 
    <?php if(isset($error) && !empty($error)) { ?><div class="alert-danger"><?php echo $error; ?></div><?php } ?>
    <?php if(isset($sucess) && !empty($sucess)) { ?><div class="alert-success"><?php echo $sucess; ?></div><?php } ?>
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
                
              
              
              
              
              </div>
              <!-- /.col-lg-12 -->
              </div>
           
            
            
           
            
            
            <div class="row">
               
                    <div class="panel panel-default">
                        <div class="panel-heading"> View User Details</div>
                        
                                
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"> 
               
        <tr>
        <td><label>Search By Username</label></td>
        <td>
        <input type="text" id="svalue" name="svalue" class="input-long" onchange="showUsers();" /></td>
        </tr>                  
          <script type="text/javascript">
        $(document).ready(function() {
			//var keyword = $('#svalue').val();
			var csrf=$('input[name="admin_token"]').val();	
            $("#svalue").tokenInput("<?php echo base_url(); ?>Search_live/search_user?admin_token="+csrf, {
                preventDuplicates: true,
				theme: "facebook",
				tokenLimit: 1 ,
				 prePopulate: [
						<?php
						if(isset($com_tag) && !empty($com_tag))
						{
							foreach($com_tag as $val) 
							{	
							 ?> 
								{id:"<?php echo  $val['id'];?>",name:"<?php echo  $val['name'];?>"},
							<?php
							 }
						}
						?>
                ]
            });
        });
        </script><br/>               
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                         <div class="table-responsive">
                            
                      <div id="getdata" class="getdata"> </div>  <!---show hide-->    
                            
                    <div id="abc">   <!---show hide-->        
                             <?php if(isset($results) && !empty($results) ){ ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                      <tr>
                                      <!--<th colspan="20" id="pages"><?php echo $links; ?></th>-->
                                      </tr>
   
                                    
                                    
                  <tr>
                      <th>ID</th>
                      <th>Username</th>
                      <th>Email</th>
<th>Total Images</th>
                      <th>Option</th>
                     </tr>
                                        
                                    </thead>
                                    <tbody>
                                    <?php 
									  $b = 0;
									  foreach($results as $data) {
									  $class = ($b++ % 2 == 0) ? 'even' : 'odd';
									  ?>
                                        <tr class="<?php echo $class; ?>">
                                            <td><?php echo $counter++; ?></td>
                                            <td><?php echo $data['name']; ?></td>
                                            <td><?php echo $data['email']; ?></td>
                                          
                                           <td><?php
$sql=$this->db->query("SELECT count(image)as img FROM `vision_board` where email='".$data['email']."'");
foreach($sql->result_array() as $rows)
{
$images=$rows['img'];
if($images >0)
{
echo $images;
}else if($images <1)
{
echo "No Images";
}
}
?>
</td> 
            
          <td> <a href="<?php echo base_url();?>Visionboard/view_img/<?php echo $data['email']; ?>"><span>View</span></a></td>                         
                                        </tr>
                                        <?php }?>
                                        <!--<tr>
                                            <td>2</td>
                                            <td>Jacob</td>
                                            <td>Thornton</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Larry</td>
                                            <td>the Bird</td>
                                            <td>@twitter</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>-->
                                    </tbody>
                                </table>
                                 <?php } else{}?>
                                 </div> <!---show hide-->
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              
                
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

 <script type="text/javascript" src="<?php echo base_url(); ?>css-admin/multisearch/src/jquery.tokeninput.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>css-admin/multisearch/styles/token-input-facebook.css" type="text/css" />

<!--<script type="text/javascript" src="<?php echo base_url();?>js/jquery.min.js"></script>--> 