<div id="page-wrapper">
              <div class="row">
              <div class="col-lg-12">
              <h3 class="page-header">Sub Partner Details</h3>
              
    <div class="display_message" id="error_msgs"> 
    <?php if(isset($error) && !empty($error)) { ?><div class="alert-danger"><?php echo $error; ?></div><?php } ?>
    <?php if(isset($sucess) && !empty($sucess)) { ?><div class="alert-success"><?php echo $sucess; ?></div><?php } ?>
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    
     <?php  $post_url=base_url()."Agent/view_subpartner";?>
    </div>
              
              
              
              
              
              </div>
              <!-- /.col-lg-12 -->
              </div>
           
            
            
           
            
            
            <div class="row">
               
                    <div class="panel panel-default">
                        <div class="panel-heading"> 
                        
<!--                        <div class="form-group">
         <form role="form" method="post" action="<?php echo $post_url;?>" enctype="multipart/form-data">
         <label for="sel1">Select Partner:</label>
      <input type="text" class="form-control" id="insurer" placeholder="Enter Insurer Name" name="insurer_name">
      <select class="form-control" id="sel1" name="agent" id="insurer" data-live-search="true" onchange="this.form.submit()">
          <option value=" ">Select Partner</option>
            <?php 
           // for($i=0; $i < count($data['name']);$i++) 
            
            foreach($result as $data)
            {?>
          
          <option value="<?php echo $data['agent_id']; ?>"> <?php echo $data['name']; ?></option>
                        
           <?php }
            
            ?>
      </select>
         </form>
     </div>-->
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                            
                            <!--<form action="<?php echo base_url();?>Change_status/user_status" method="post" />-->     
                         
                            <!--<input type="submit" class="btn-info" name="s1" value="Change Status" class="submit-gray" /> -->
                            
                             <?php if(isset($results) && !empty($results) ){ ?>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                      <tr>
                                      <th colspan="20" id="pages"><?php echo $links; ?></th>
                                      </tr>
   
                                    
                                    
                                      
                  <tr>
                      <th>ID</th>
                      <th>Sub-Partner Name</th>
                      <th>Company Name</th>
                      <th>Person Name</th> 
                      <th>Address</th>
                      <th>City</th>
                      <th>State</th>
                      <th>Pincode</th>
                      <th>Mobile</th>
                      <th>Email</th>
                      <th>Date</th>
                      
                      <!--<th><input type="checkbox" name="chkall" id="chkall" onchange="myFunction()" value="A" />Status</th>-->
                     <th>Option</th>
                     </tr>
                                        
                                    </thead>
                                    <tbody>
                                    <?php 
									  $b = 0;
									  foreach($results as $data) {
									  $class = ($b++ % 2 == 0) ? 'even' : 'odd';
									  ?>
                                        <tr class="<?php echo $class; ?>">
                                            <td><?php echo $counter++; ?></td>
                                            <td><?php echo $data['name']; ?></td>
                                            <td><?php echo $data['company_name']; ?></td>
                                            <td><?php echo $data['person_name']; ?></td>
                                            <td><?php echo $data['address']; ?></td>
                                            <td><?php echo $data['city']; ?></td>
                                            <td><?php echo $data['state']; ?></td>
                                            <td><?php echo $data['pin']; ?></td>
                                            <td><?php echo $data['mobile']; ?></td>
                                            <td><?php echo $data['email_id']; ?></td>
                                            <td><?php echo $data['date']; ?></td>
                                    
          <!--<td><input type="checkbox" name="excel[]" class="chk" value="<?php echo $data['reg_id'];?>" /></form></td> -->   
          <td> 
          <a href="<?php echo base_url();?>Agent/edit/<?php echo $data['agent_id'];?>"><span>Edit</span></a>
          <a href="<?php echo base_url();?>Delete/delete_agent/<?php echo $data['agent_id'];?>"><span>Delete</span></a>
          
          </td>                         
                                        </tr>
                                        <?php }?>
                                        <!--<tr>
                                            <td>2</td>
                                            <td>Jacob</td>
                                            <td>Thornton</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Larry</td>
                                            <td>the Bird</td>
                                            <td>@twitter</td>
                                            <td>@fat</td>
                                            <td>@fat</td>
                                        </tr>-->
                                    </tbody>
                                </table>
                                 <?php } else{}?>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
              
                
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

   <script>
function myFunction() 
{
//alert(document.getElementsByName("chk")[0]);

var x=document.getElementsByClassName("chk");
	//alert(x.length);
if (document.getElementById("chkall").checked== true)
{
	
	for(i=0; i<x.length; i++)
	{
	  
	  x[i].checked= true;
	 // x[i].disabled = true;
	   
	}
}

else
{
  for(i=0; i<x.length; i++)
	{
	  
	  x[i].checked= false;
	 // x[i].disabled = true;
	   
	}

}
}
</script>

