
<html>
    <head>
        <title>Bootstrap Carousel Guide by Bootstrapious.com</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
        <link href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,700' rel='stylesheet' type='text/css'>
        <link href='custom.css' rel='stylesheet' type='text/css'>
        <link href="dropzone/dist/dropzone.css" type="text/css" rel="stylesheet" />
        <script src="dist/sweetalert.min.js"></script> 
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">  
        <script src="dropzone/dist/dropzone.js"></script>
        
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
<script>
    Dropzone.options.myAwesomeDropzone = { // The camelized version of the ID of the form element

  // The configuration we've talked about above
 // autoProcessQueue: false,
  uploadMultiple: false,
  addRemoveLinks:true,
  //parallelUploads: 100,
  //maxFiles: 100,

  // The setting up of the dropzone
  init: function() {
    var myDropzone = this;

    // First change the button to actually tell Dropzone to process the queue.
    this.element.querySelector("button[type=button]").addEventListener("click", function(e) {
      // Make sure that the form isn't actually being sent.
      e.preventDefault();
      e.stopPropagation();
      myDropzone.processQueue();
    });
    
    this.on("success", function(file, responseText) {
            document.querySelector(".dz-progress").style.opacity = "0";
            $('#nextStep').html('<a href="<?php echo 'employee?id='.$empID.'&step=3'; ?>" class="button form-button">Next</a>');
        });
    var mockFile = { name: "Filename", size: 12345 };
myDropzone.options.addedfile.call(myDropzone, mockFile);
// And to show the thumbnail of the file:
myDropzone.options. thumbnail.call(myDropzone, mockFile, "uploads/");
     myDropzone.on("queuecomplete", function (file) {
          sweetAlert("Success! Please click on Preview button to open the uploaded file");
      });
myDropzone.on("complete", function(file) {
  myDropzone.removeAllFiles();
//  $('#type').val('');
//  $('#insurer').val('');
//  $('#policy_holder').val('');
//  $('#mobile').val('');
//  $('#email').val('');
//  sweetAlert("Success","File Upload","Please click on Preview to open the uploaded file");
//  
});
    // this.on("addedfile", function(file) { alert("Added file."); });

    // Listen to the sendingmultiple event. In this case, it's the sendingmultiple event instead
    // of the sending event because uploadMultiple is set to true.
    this.on("sendingmultiple", function() {
      // Gets triggered when the form is actually being sent.
      // Hide the success button or the complete form.
    });
    this.on("successmultiple", function(files, response) {
      // Gets triggered when the files have successfully been sent.
      // Redirect user or notify of success.
    });
    this.on("errormultiple", function(files, response) {
      // Gets triggered when there was an error sending the files.
      // Maybe show form again, and notify user of error
    });
  }

}
    </script>
    
  
    
    </head>
    
    
    <body style="background: #808080">
 <!--<a href="uploads/<?php echo $file;?>" target="_blank">Show My Pdf</a>-->
        <!-- fullscreen -->
        <div class="modal-body row" >
           <div class="col-md-4" style="width: 40%;" >
<!--               <form action="#" method="post">-->

<?php $post_url='Upload/do_upload' ?>
                        <!-- HTML heavily inspired by http://blueimp.github.io/jQuery-File-Upload/ -->
         <form  id="my-awesome-dropzone" action="<?php echo $post_url;?>" class="dropzone" enctype= multipart/form-data method="post" >
        
<!--            <div class="form-group">   
         <button  type="button" value="submit" class="btn btn-default" >Upload</button>
         </div>-->
         </form>
                        <!--<div class="dropzone-previews"></div>-->
<form>
    <div class="form-group">  
        
        <?php
        
            foreach($files as $data)
            {?>
       
        <button type="button"  class="btn btn-default" onclick="window.open('uploads/<?php echo $data['file_name'];?>','demo','width=550,height=300,left=150,top=200,toolbar=0,status=0,')">Preview</button>
    <?php }?>
           
                
            
    </div>    
</form>
<?php $post_url1='File/add' ?>
<form action="<?php echo $post_url1;?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
      <!--<label for="sel1" style="color: #fff">Type of policy:</label>-->
      <select class="form-control" id="sel1" name="type" id="type" data-live-search="true">
          <option value=" ">Select Policy Type </option>
   
           <?php 
            foreach($policy as $data)
            {?>
          <option value=<?php echo $data['policy_id'] ?>> <?php echo $data['type'] ?></option>
                        
          <?php }
            
            ?>
          
           
      </select>
      </div>
  <div class="form-group">
       <?php 
            foreach($files as $data)
            {?>
    <input type="hidden" id="id" name="id" value="<?php echo $data['id'] ;?>">
    <input type="hidden" id="policy" name="policy" value="<?php echo $data['file_name'] ;?>">
    <?php }
            
            ?>
  </div>
     <div class="form-group">
         
         <!--<label for="sel1" style="color: #fff">Insurer Name:</label>-->
      <!--<input type="text" class="form-control" id="insurer" placeholder="Enter Insurer Name" name="insurer_name">-->
      <select class="form-control" id="sel1" name="insurer" id="insurer" data-live-search="true">
        <option value=" ">Select Insurer</option>
           <?php 
            foreach($insurer as $data)
            {?>
          <option value="<?php echo $data['insurer_id']?>"> <?php echo $data['name'] ?></option>
                        
           <?php }
            
            ?>
      </select>
             
     </div>
      <div class="form-group">
      <input type="text" class="form-control" id="policy_holder" placeholder="Enter Policy Holder Name" name="policy_holder">
      </div>
      <div class="form-group">
          <input type="text" class="form-control" id="mobile" placeholder="Enter Mobile Number" name="mobile">
      </div>
      <div class="form-group">
       <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email">
    </div>

<button  type="submit" value="submit" class="btn btn-default" >Save</button>
        
                        
                </form> 
        
 </div>
           
           <div class="col-md-4" style="width: 60%">
        <div id="carousel-example-generic2" class="carousel  carousel-fullscreen casliderousel-fade" data-ride="carousel" >
            <!-- Indicators -->
   
            
            <!--<ol class="carousel-indicators">
                <li data-target="#carousel-example-generic2" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic2" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic2" data-slide-to="2"></li>
            </ol>-->

            <!-- Wrapper for slides -->
            
            <div class="carousel-inner" role="listbox">
                 
                <div class="item active" style="background-image: url('img/carousel1.jpg');">
                    <div class="overlay"></div>
                    
                     <nav class="navbar">
                        <div class="container-fluid">
                         <!-- <div class="navbar-header">
                            <a class="navbar-brand" href="#"  style="color: white">serve my policy</a>
                          </div>-->

                          <ul class="nav navbar-nav navbar-right">
                           <div class="btn-group">
                               <a href="https://www.w3schools.com/" <button type="button" class="btn btn-default">Reports</button></a>
                        <button type="button" class="btn btn-default">MyInfo</button>
                        <button type="button" class="btn btn-default">Logout</button>
                           </div>   
                        </ul>
                        </div>
                          </nav>
                   
                </div>


   </div>
        
               
                <!--<div class="item" style="background-image: url('img/carousel2.jpg');">
                    <div class="overlay"></div>
                   
                    
                     <nav class="navbar">
                        <div class="container-fluid">
                          <div class="navbar-header">
                            <a class="navbar-brand" href="#"  style="color: white">serve my policy</a>
                          </div>

                          <ul class="nav navbar-nav navbar-right">
                           <div class="btn-group">
                        <button type="button" class="btn btn-default">Reports</button>
                        <button type="button" class="btn btn-default">MyInfo</button>
                        <button type="button" class="btn btn-default">Logout</button>
                           </div>   
                        </ul>
                        </div>
                    </nav>
                    
                   
                </div>
                <div class="item" style="background-image: url('img/carousel3.jpg');">
                    <div class="overlay"></div>
                   

                     <nav class="navbar">
                        <div class="container-fluid">
                          <div class="navbar-header">
                            <a class="navbar-brand" href="#"  style="color: white">serve my policy</a>
                          </div>

                          <ul class="nav navbar-nav navbar-right">
                           <div class="btn-group">
                        <button type="button" class="btn btn-default">Reports</button>
                        <button type="button" class="btn btn-default">MyInfo</button>
                        
                        
                        <button type="button" class="btn btn-default">Logout</button>
                           </div>   
                        </ul>
                        </div>
                    </nav>
                   
                    
                </div>-->
            </div>
            </div>
   
        </div>
        
        

      
        <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
