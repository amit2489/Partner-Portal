        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Belief</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Add Belief
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6" style="width:100%">
                                
                                 <?php 
								  if(isset($eid))
								  {
								  $post_url=base_url()."Belief/update";	
								  }else{ 
								  $post_url=base_url()."Belief/Add";
								  }
								  ?>
    <div class="display_message" id="error_msgs"> 
    <?php
    if($this->session->flashdata('error')){echo "<div class=alert-danger>".$this->session->flashdata('error')."</div>";}
    if($this->session->flashdata('sucess')){echo "<div class=alert-success>".$this->session->flashdata('sucess')."</div>";}
	?>
    </div>
         
         
                                  
                                  
         <?php echo "<div class=alert-danger>".validation_errors()."</div>"; ?>  
                               
        <form role="form" method="post" action="<?php echo $post_url;?>" enctype="multipart/form-data">
        
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">         
         
         
         <input type="hidden" id="eid" name="eid" value="<?php if(isset($eid)){echo $eid;}?>" />
         

<div class="form-group">
        <label>Selects Days</label>
        <select class="form-control" name="days" id="days" required>
            <option value="">Select Days</option>
            
            <?php if(isset($days))
			    {
				foreach($days as $cat)
				
				{ ?>
        <!-- <option value="<?php echo $cat['days_id'];?>"><?php echo $cat['days'];?></option>-->
          
   <option value="<?php echo $cat['days_id'];?>" <?php if(isset($get_results) && $get_results['days'] == $cat['days_id'])
   {echo "selected";}
   ?>><?php echo $cat['days'];?></option>
                  
             <?php
				}
				}
			?>
            
            
            
        </select>
        </div>  






          
        <div class="form-group">
        <label>Selects Belief</label>
        <select class="form-control" name="belief" id="belief" required>
            <option value="">Selects Belief</option>
            <option value="1">Failure inducing belief</option>
            <option value="2">Success inducing belief</option>
        </select>
        </div>  
          
          
          
          
                                       
        <div class="form-group">
        <label>Title</label>
        <input class="form-control" placeholder="Enter Title" name="title" id="title" value="<?php if(isset($get_results)){echo $get_results['Title'];}?><?php echo set_value('Title'); ?>" required>
         
        </div>
                    
       <div class="form-group">
       <label>Description</label>
       <textarea class="form-control" rows="5" name="description" id="description" value="" ><?php if(isset($get_results)){echo $get_results['Description'];}?><?php echo set_value('Description'); ?></textarea>
       <script>
		CKEDITOR.replace( 'description', {
        filebrowserUploadUrl: "<?php echo base_url(); ?>upload/upload.php" } );
	   </script>
        </div>
        
        
        <button type="submit" class="btn btn-primary btn-lg btn-block" name="save_question" value="save">Save</button>
        </form>
                             
                                </div>
                               
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    
