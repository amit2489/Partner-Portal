<?php
Class User extends CI_Model
{
public function __construct()
	{
			$this->load->helper('cookie');
	}
 function login($username, $password,$status)
 
 {
   $this -> db -> select('*');
   $this -> db -> from('user_login');
   $this -> db -> where('email',$username);
  //  $this -> db -> where('status',$status);
   $this -> db -> where('password',md5($password));
   $this -> db -> where('status',1);
  
   $this -> db -> limit(1);

   $query = $this -> db -> get();

   if($query -> num_rows() == 1)
   {
     return $query->result();
   }
   else
   {
     return false;
   }
 
 }
 public function remember($user)
 {
$s = strtoupper(md5(uniqid(rand(),true)));
$status=1; 
    $guidText = 
        substr($s,0,9);
	
		
		$cookie_name="guidText";
		$cookie_value=$guidText;

			setcookie($cookie_name,$cookie_value, time() + 86400);
		$myarray=array('id'=>$guidText,'user_id'=>$user,'status'=>$status);
		$this->db->insert('remember',$myarray);
		
}
}
 