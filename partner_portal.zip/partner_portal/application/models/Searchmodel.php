<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class searchmodel extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}
	
/*function builder_search_get($svalue)
	{
	$parr=array();
	$this->db->select('Name as name,b_id as id'); 
    $this->db->from('body_info');
	//$this->db->or_like('Name',$svalue,'after');
	//$this->db->or_lile('group',$svalue,'after');
	//$this->db->where('status',0);
	//$this->db->where('status','Active');
	$this->db->limit(15);
	$q = $this->db->get();
	
	if($q->num_rows() > 0)
	{
			foreach ($q->result() as $row)
			{	
			  $arr1=array();
			  $arr1['id']=$row->name;
			  $arr1['name']=$row->name;
			  //$arr1['group']=$row->group;
			  //$arr1['code']=$row->code;
			  $parr[]=$arr1;
			}
	}

	
	if(isset($parr) && count($parr) > 0 )
	   {
	
			return json_encode($parr);
		}
	 }*/
	 	
	function search_user($scompetition)
	{
	$parr=array();
	$this->db->select('name as name,reg_id as id'); 
    $this->db->from('registration');
$this->db->like('name',$scompetition,'after');
	$this->db->where('status',1);
	$this->db->limit(15);
	$q = $this->db->get();
	
	if($q->num_rows() > 0)
	{
			foreach ($q->result() as $row)
			{	
			  $arr1=array();
			  $arr1['id']=$row->name;
			  $arr1['name']=$row->name;
			  $parr[]=$arr1;
			}
	}

	
	if(isset($parr) && count($parr) > 0 )
	   {
	
			return json_encode($parr);
		}
	 }
	  	
	
	
	
	
	
	function gym_search_get($gymname)
	{
	$parr=array();

	$this->db->select('gym_name as name,id as id'); 
    $this->db->from('gym_details');
	//$this->db->or_like('gym_name',$gym_details,'after');
	//$this->db->where('status',0);
	//$this->db->where('status','Active');
	$this->db->limit(15);
	$q = $this->db->get();
	
	if($q->num_rows() > 0)
	{
			foreach ($q->result() as $row)
			{	
			  $arr1=array();
			  $arr1['id']=$row->name;
			  $arr1['name']=$row->name;
			  //$arr1['code']=$row->code;
			  $parr[]=$arr1;
			}
	}

	
	if(isset($parr) && count($parr) > 0 )
	   {
	
			return json_encode($parr);
		}
	 }






 function builder_search_get($svalue)
	{
	$parr=array();
	$this->db->select('title as name,news_id as id'); 
    $this->db->from('news');
	$this->db->like('title',$svalue,'after');
	//$this->db->or_like('Name',$svalue,'after');
	//$this->db->or_lile('group',$svalue,'after');
	//$this->db->where('status',0);
	//$this->db->where('status','Active');
	$this->db->limit(15);
	$q = $this->db->get();
	
	if($q->num_rows() > 0)
	{
			foreach ($q->result() as $row)
			{	
			  $arr1=array();
			  $arr1['id']=$row->name;
			  $arr1['name']=$row->name;
			  //$arr1['group']=$row->group;
			  //$arr1['code']=$row->code;
			  $parr[]=$arr1;
			}
	}

	
	if(isset($parr) && count($parr) > 0 )
	   {
	
			return json_encode($parr);
		}
	 }
	 	
	
	
	public function get_user_details($search)
    {
		
		$this->db->select('*'); 
		$this->db->from('registration');
		$whereCondition = array('name' =>$search);
		$this->db->where($whereCondition);
		$query=$this->db->get();
	    if($query->num_rows() > 0)
		{
		  foreach($query->result() as $row)
		  {
		  $data[]=$row;
		  }
		  return json_encode($data);
		  }
		}
	



	 	 	 

}