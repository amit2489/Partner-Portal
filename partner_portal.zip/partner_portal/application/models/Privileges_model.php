<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Privileges_model extends CI_Model
{
	public function __construct()
	{
		$this->load->library('session');
		$this->load->helper('url');
	}
	
	
	
function admin() 
{ 
$a=array();

 //$user=$this->session->userdata['id']['muser_id'];
 
$a['Home']=array('REPORTS'=>'Home/Main','CHANGE PASSWORD'=>'Password/form');
$a['Rg_user']=array('ADD PARTNER DETAILS'=>'Agent/form','PARTNER DETAILS'=>'Agent/view','SUB-PARTNER DETAILS'=>'Agent/view_subpartner','SUB-SUB PARTNER DETAILS'=>'Agent/view_sub_subpartner','PARTNER SUB-PARTNER DETAILS'=>'Agent/partner_subpartner','SUB-PARTNER & SUB-SUB PARTNER DETAILS'=>'Agent/subpartner_subsubpartner');
$a['Insurer']=array('ADD INSURER'=>'Insurer/form','INSURER DETAILS'=>'Insurer/view');
//$a['Rg_user']=array('Add AGENT DETAILS'=>'Agent/add');
//$a['Question']=array('Add Question'=>'Question/form','View Question'=>'Question/view');
$a['Policy']=array('ADD POLICY TYPE'=>'Policy/form','POLICY DETAILS'=>'Policy/view');
$a['Uploaded_policy']=array('UPLOADED POLICY DETAILS'=>'Uploaded_policy/view');
$a['Slider_images']=array('ADD IMAGE'=>'Slider_images/form','UPLOADED SLIDER IMAGES'=>'Slider_images/view');
$a['Insurer_policy']=array('VIEW REPORT'=>'Insurer/report');
$a['Policy_report']=array('VIEW REPORT'=>'Policy/report');



//$a['Exercise']=array('Add Exercise '=>'Exercise/form','View Exercise '=>'Exercise/view');

//$a['company']=array('ADD INSURER'=>'Insurer/form','INSURER DETAILS'=>'Insurer/view');

//$a['Coach']=array('ADD EXERCISE '=>'Exercise/form','VIEW EXERCISE  '=>'Exercise/view','ADD BELIEF '=>'Belief/form','VIEW BELIEF '=>'Belief/view','ADD COACH'=>'Question/form','VIEW COACH'=>'Question/view');

//$a['emotion']=array('ADD EMOTIONS '=>'Emotions/form','VIEW EMOTIONS'=>'Emotions/view','ADD SOLUTION'=>'Emotions/solution_form','VIEW SOLUTION'=>'Emotions/solution_view');  

//$a['tips']=array('ADD TIPS'=>'Tips/form','VIEW TIPS'=>'Tips/view');


    return $a;
	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

?>