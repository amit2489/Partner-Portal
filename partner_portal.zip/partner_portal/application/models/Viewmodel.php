<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class viewmodel extends CI_Model
{
    public function __construct()
	 {
            parent::__construct();
		    $this->load->model("stringmodel"); 
			$this->load->helper('url');
			$this->load->library('session');
			
     }

    public function count_total_rows($table_name)
    {
        return $this->db->count_all("$table_name");
    }
	
  
  
  public function  fetch_agents() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('d_agent');
                $this->db->order_by("agent_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
  
  //---------------------------------------------------------//
   
   
   
   public function  fetch_sub_partner() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('sub_partner');
                $this->db->order_by("sub_partner_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
  
  //---------------------------------------------------------//
   
   
   public function  fetch_sub_sub_partner() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('sub_sub_partner');
                $this->db->order_by("sub_sub_partner_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
  
  //---------------------------------------------------------//
   
   
   
     public function  fetch_insurer() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('d_insurer');
                $this->db->order_by("insurer_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
   
   
   //---------------------------------------------------------//
   
   
  
   
     public function  fetch_policy() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('d_policy');
                //$this->db->order_by("reg_time","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
   
    //---------------------------------------------------------//
   
   
  
   
     public function  fetch_files() 
	{
                $this->db->limit(1);
		$this->db->select('*');
		$this->db->from('files');
                $this->db->order_by("uploaded","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
   //---------------------------------------------------------//
   
   
   public function  fetch_uploadedpolicy() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('d_uploaded_policy');
                $this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
   //---------------------------------------------------------//
   
   
   public function  fetch_uploadedpolicy_id($id) 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('d_uploaded_policy');
                $this->db->where('file_id',$id);
                $this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
  
   //---------------------------------------------------------//
   
   
   public function  fetch_insurer_policy($insurer_id) 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('d_insurer.*,d_policy.*,files.*,d_uploaded_policy.*');
		$this->db->from('d_uploaded_policy');
                $this->db->join('d_insurer', 'd_uploaded_policy.insurer_id = d_insurer.insurer_id', 'inner');
                $this->db->join('d_policy', 'd_uploaded_policy.policy_id = d_policy.policy_id', 'inner');
                $this->db->join('files', 'd_uploaded_policy.file_id = files.id', 'inner');
                $array = array('d_uploaded_policy.insurer_id' => $insurer_id);
                $this->db->where($array);
                //$this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
   
   //---------------------------------------------------------//
   
   
   public function  fetch_all_uploadedpolicy() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('d_insurer.*,d_policy.*,files.*,d_uploaded_policy.*');
		$this->db->from('d_uploaded_policy');
                $this->db->join('d_insurer', 'd_uploaded_policy.insurer_id = d_insurer.insurer_id', 'inner');
                $this->db->join('d_policy', 'd_uploaded_policy.policy_id = d_policy.policy_id', 'inner');
                $this->db->join('files', 'd_uploaded_policy.file_id = files.id', 'inner');
                //$array = array('d_uploaded_policy.insurer_id' => $insurer_id);
               // $this->db->where($array);
                $this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   }
   
   
   
     //---------------------------------------------------------//
   
   
   public function  fetch_all_products() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('d_insurer.*,d_policy.*,d_product.*');
		$this->db->from('d_product');
                $this->db->join('d_insurer', 'd_product.insurer_id = d_insurer.insurer_id', 'inner');
                $this->db->join('d_policy', 'd_product.policy_id = d_policy.policy_id', 'inner');
               // $this->db->join('d_commission', 'd_product.commission_id = d_commission.commission_id', 'inner');
                //$array = array('d_uploaded_policy.insurer_id' => $insurer_id);
               // $this->db->where($array);
               // $this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   }
   
     //---------------------------------------------------------//
   
   
   public function  fetch_products($insurer_id,$policy_id) 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('d_insurer.*,d_policy.*,d_commission');
		$this->db->from('d_product');
                $this->db->join('d_insurer', 'd_product.insurer_id = d_insurer.insurer_id', 'inner');
                $this->db->join('d_policy', 'd_product.policy_id = d_policy.policy_id', 'inner');
                $this->db->join('d_commission', 'd_product.commission_id = d_commission.commission_id', 'inner');
                $array = array('d_product.insurer_id' => $insurer_id,'d_product.policy_id' => $policy_id);
                $this->db->where($array);
               // $this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   }   
   
   
    //---------------------------------------------------------//
   
   
   public function  fetch_policy_report($policy_id) 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('d_insurer.*,d_policy.*,files.*,d_uploaded_policy.*');
		$this->db->from('d_uploaded_policy');
                $this->db->join('d_insurer', 'd_uploaded_policy.insurer_id = d_insurer.insurer_id', 'inner');
                $this->db->join('d_policy', 'd_uploaded_policy.policy_id = d_policy.policy_id', 'inner');
                $this->db->join('files', 'd_uploaded_policy.file_id = files.id', 'inner');
                $array = array('d_uploaded_policy.policy_id' => $policy_id);
                $this->db->where($array);
                //$this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
   
   
   //---------------------------------------------------------//
   
   
   public function  fetch_partner_subpartner($agent_id) 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('sub_partner.*');
		$this->db->from('d_agent');
                $this->db->join('sub_partner', 'd_agent.agent_id = sub_partner.agent_id', 'inner');
                $array = array('d_agent.agent_id' => $agent_id);
                $this->db->where($array);
                //$this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   }
   
   
   //---------------------------------------------------------//
   
   
   public function  fetch__subpartner_subsubparter($subpartner_id) 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('sub_sub_partner.*');
		$this->db->from('sub_partner');
                $this->db->join('sub_sub_partner', 'sub_partner.sub_partner_id = sub_sub_partner.sub_partner_id', 'inner');
                $array = array('sub_partner.sub_partner_id' => $subpartner_id);
                $this->db->where($array);
                //$this->db->order_by("up_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   }
   
   
   
   
   
   //---------------------------------------------------------//
   
   
   
     public function  fetch_slider_images() 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('*');
		$this->db->from('d_slider_images');
                $this->db->order_by("img_id","desc");
		$query = $this->db->get();
	        if ($query->num_rows() > 0) {
                foreach ($query->result() as $row)
                {
                $data[] = $row;
                }
                return json_encode($data);
                }
                return false;
   } 
   
  //---------------------------------------------------------//
  
  

 
   public function fetch_days() 
	{
        
		$this->db->select('*');
		$this->db->from('days');
               $query = $this->db->get();
	    if ($query->num_rows() > 0) 
		{
            foreach ($query->result() as $row) 
			{
                $data[] = $row;
            }
            return json_encode($data);
        }
        return false;
   }  
  

  //---------------------------------------------------------//
   
    public function fetch_file($id) 
	{
    
	$this->db->select('*');
	$this->db->from('files');
        $this->db->order_by("Belief_time","desc");
	$query = $this->db->get();
    if ($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }    
   
   
   
   
 public function fetch_userlist() 
	{
        
		$this->db->select('*');
		$this->db->from('registration');
		$this->db->where('status',1);
        $this->db->order_by("reg_time","desc");
        $query = $this->db->get();
	    if ($query->num_rows() > 0) 
		{
            foreach ($query->result() as $row) 
			{
                $data[] = $row;
            }
            return json_encode($data);
        }
        return false;
   }    
   
   
   
 public function fetch_Image($useremail) 
	{
        
		$this->db->select('*');
		$this->db->from('vision_board');
		$this->db->where('email',$useremail);
        $this->db->order_by("v_time","desc");
        $query = $this->db->get();
	    if ($query->num_rows() > 0) 
		{
            foreach ($query->result() as $row) 
			{
                $data[] = $row;
            }
            return json_encode($data);
        }
        return false;
   }    
     
   
  public function fetch_Belief($id) 
	{
    
	$this->db->select('*');
	$this->db->from('belief');
        $this->db->order_by("Belief_time","desc");
	$query = $this->db->get();
    if ($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }    


public function fetch_Exercise($id) 
	{
    
	$this->db->select('*');
	$this->db->from('exercise');
         $this->db->order_by("Ex_time","desc");
	$query = $this->db->get();
       
    if ($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }   


 public function fetch_company($id) 
	{
    
	$this->db->select('*');
	$this->db->from('company');
	$this->db->order_by("comp_time","desc");
	$query = $this->db->get();
    if ($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }  





  public function fetch_em_cat() 
	{
    
	$this->db->select('*');
	$this->db->from('emo_cat');
	$this->db->order_by("em_time","desc");
	$query = $this->db->get();
    if ($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }  
	
	
	
 public function fetch_emotions() 
	{
    
	$this->db->select('*');
	$this->db->from('emotions_mgmt');
	$this->db->order_by("em_time","desc");
	$query = $this->db->get();
    if ($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }    	
	








 public function fetch_option_em($id) 
	{
    
	$this->db->select('*');
	$this->db->from('em_option');
	$this->db->where('em_cat_id',$id);
    $query = $this->db->get();
    if ($query->num_rows() > 0) {
    foreach ($query->result() as $row) {
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }




public function fetch_emotions_solution() 
  {
    
	$this->db->select('*');
	$this->db->from('emo_solution');
	$this->db->order_by("sol_time","desc");
	$query = $this->db->get();
        if ($query->num_rows() > 0) {
        foreach ($query->result() as $row) {
        $data[] = $row;
       }
        return json_encode($data);
       }
        return false;
    }   




public function fetch_tips() 
	{
    
	  $this->db->select('*');
	  $this->db->from('tips');
	  $this->db->order_by("tips_time","desc");
	  $query = $this->db->get();
	  
    if ($query->num_rows() > 0) 
	{
    foreach ($query->result() as $row) 
	{
    $data[] = $row;
    }
    return json_encode($data);
    }
    return false;
    }  



 

}
?>