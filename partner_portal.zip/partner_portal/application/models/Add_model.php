<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Add_model extends CI_Model
{
	public function __construct()
	{
			$this->load->model("stringmodel");
			$this->load->helper('url');
			$this->load->library('session');
			$this->load->database();
                        $this->load->helper('date');
			
	}


	   
 /*public function question($Option,$title,$days,$seq,$question,$pollopt,$dropdwn)
  {    
		
		
		if(!empty($pollopt))
		{
			$my_array = array('title'=>$title,'days'=>$days,'sequence'=>$seq,'question'=>$question);
		    $this->db->insert('question',$my_array);
		    $q_id = $this->db->insert_id();
			
			
			
		foreach($pollopt as $index=>$poll)
		{
		    $myarray1=array('q_id'=>$q_id,'answer'=>$poll,'option'=>$dropdwn[$index]);
		    $this->db->insert('question_answer',$myarray1);
		   }
		$cnt=$this->db->affected_rows();
	    if(isset($cnt) && $cnt > 0)
		 {
			return 1;
		 }
		 else
		 {
			return 2; 
		 }
		}
		else
		{
			return 3;
			}
       }*/


//Change password
public function Change($email,$new_pass,$old_pass,$con_pass)
{
//echo "select * from login where email='".$email."' and password='".md5($old_pass)."'";
$query=$this->db->query("select * from login where email='".$email."' and password='".md5($old_pass)."'");
if($query->num_rows() > 0)
{
$sql=$this->db->query("update login set password='".md5($new_pass)."' where email='".$email."'");
if($sql)
{
return 1;
}
else
{
return 3;
}
}else
{
return 2;}



} 	




 public function agent($name,$address,$mobile,$email,$person,$company,$city,$state,$pin)
	 {
			$now= date('Y-m-d H:i:s');
			$myarray=array('name'=>$name,'address'=>$address,'email_id'=>$email,'mobile'=>$mobile,'person_name'=>$person,'company_name'=>$company,'city'=>$city,'state'=>$state,'pin'=>$pin,'date'=>$now);
			$this->db->insert('d_agent',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	}  
  	 
public function insurer($name)
	 {
			
			$myarray=array('name'=>$name);
			$this->db->insert('d_insurer',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	} 
        
        
        
        public function files($file_name)
	 {
                        //$now=NOW();
			$now = date('Y-m-d H:i:s');
                        //$data['uploaded'] =  date('Y-m-d H:i:s');
			$myarray=array('file_name'=>$file_name,'uploaded'=>$now);
			$this->db->insert('files',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	} 
        
        
        
public function policy($type)
	 {
			
			$myarray=array('type'=>$type);
			$this->db->insert('d_policy',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	} 
        

        
public function sub_partner($agent_id,$name,$address,$mobile,$email,$company,$person,$city,$state,$pin)
	 {
			$now = date('Y-m-d H:i:s');
			$myarray=array('agent_id'=>$agent_id,'name'=>$name,'address'=>$address,'mobile'=>$mobile,'email_id'=>$email,'company_name'=>$company,'person_name'=>$person,'city'=>$city,'state'=>$state,'pin'=>$pin,'date'=>$now);
			$this->db->insert('sub_partner',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	} 
        
        
public function sub_sub_partner($sub_partner_id,$name,$address,$mobile,$email,$company,$person,$city,$state,$pin)
	 {
			$now = date('Y-m-d H:i:s');
			$myarray=array('sub_partner_id'=>$sub_partner_id,'name'=>$name,'address'=>$address,'mobile'=>$mobile,'email_id'=>$email,'company_name'=>$company,'person_name'=>$person,'city'=>$city,'state'=>$state,'pin'=>$pin,'date'=>$now);
			$this->db->insert('sub_sub_partner',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	} 
        
        
        
        
public function uploaded_policy($file_id,$policy,$policy_id,$insurer_id,$policy_holder,$mobile,$email)
	 {
			
			$myarray=array('policy'=>$policy,'policy_id'=>$policy_id,'insurer_id'=>$insurer_id,'policy_holder_name'=>$policy_holder,'mobile'=>$mobile,'email_id'=>$email,'file_id'=>$file_id);
			$this->db->insert('d_uploaded_policy',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	} 
        
        
        
           public function product($product_name,$insurer_id,$policy_id,$base_rate,$delta_rate,$final_rate)
	 {
			
			$myarray=array('product_name'=>$product_name,'insurer_id'=>$insurer_id,'$policy_id'=>$policy_id,'base_rate'=>$base_rate,'delta_rate'=>$delta_rate,'final_rate'=>$final_rate);
			$this->db->insert('d_product',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	}  
        
        
        
        
        public function image_slider($name)
	 {
			
			$myarray=array('name'=>$name);
			$this->db->insert('d_slider_images',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	}  
        






/*public function Emotions($days,$title,$description)
	 {
			
			$myarray=array('em_cat_id'=>$days,'em_title'=>$title,'em_desc'=>$description);
			$this->db->insert('emotions_mgmt',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	}  */


public function Emotions($days,$title,$description,$pollopt)
{
   if(!empty($pollopt))
   {
			$myarray=array('em_cat_id'=>$days,'em_title'=>$title,'em_desc'=>$description);
			$this->db->insert('emotions_mgmt',$myarray);
			$q_id = $this->db->insert_id();
			
			foreach($pollopt as $index=>$poll)
		    {
		    $myarray1=array('em_cat_id'=>$q_id,'em_des_option'=>$poll);
		    $this->db->insert('em_option',$myarray1);
		    }
			$cnt=$this->db->affected_rows();
			
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	}
	else
	{
	return 3;
	}
}  



    public function solution($days,$title,$description)
	 {
			
			$myarray=array('em_cat_id'=>$days,'title'=>$title,'description'=>$description);
			$this->db->insert('emo_solution',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	}







public function tips($days,$description)
	 {
			$myarray=array('days'=>$days,'tips'=>$description);
			$this->db->insert('tips',$myarray);
			$cnt=$this->db->affected_rows();
			if(isset($cnt) && $cnt > 0)
			{
			return 1;
			}
			else
			{
			return 2; 
			}
	}  	







	   
	   
}?>