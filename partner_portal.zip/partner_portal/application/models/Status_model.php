<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class status_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
		$this->load->model("Edit_model");
	}
  
	
	
	public function user_status($id)
	{
		$ids = join("','",$id);
		//$query=$this->db->query("UPDATE registration SET status = IF(status=1, 0, 1) where reg_id='$id'");
		$query=$this->db->query("UPDATE registration SET status = IF(status=1, 0, 1) WHERE reg_id IN ('$ids')");
		$query=$this->db->affected_rows();
		if(isset($query) && $query > 0){
		return json_encode(1);
		}else{
		return json_encode(2); }
	}
  
	 

	public function company_status($id)
	{
		$ids = join("','",$id);
		  
		$query=$this->db->query("UPDATE company SET comp_status = IF(comp_status=1, 0, 1) WHERE comp_id IN ('$ids')");
		$query=$this->db->affected_rows();
		if(isset($query) && $query > 0)
		{
		return json_encode(1);
		}
		else
		{
		return json_encode(2); 
		}
	}  	  
	  

   }