<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class edit_model extends CI_Model
{
	public function __construct()
	{
			$this->load->model("stringmodel"); 
			$this->load->helper('url');
			$this->load->library('session');
	}

	
       //get_files 
        public function get_files($id)
	{
		$this->db->select('*'); 
		$this->db->from('files');
                
                
		$my_array = array('file_id' => $id);
		$this->db->where($my_array);
                 $this->db->order_by("file_id","desc");
		$this->db->limit(1);
		$q = $this->db->get();
		
		if($q->num_rows() > 0)
		{
			foreach ($q->result() as $row)
			{
			  $data = $row;
			}
			return json_encode($data);
		}
	}	
        
        
        
//get_agents	
	
public function get_agents($id)
	{
		$this->db->select('*'); 
		$this->db->from('d_agent');
		$my_array = array('agent_id' => $id);
		$this->db->where($my_array);
		$this->db->limit(1);
		$q = $this->db->get();
		
		if($q->num_rows() > 0)
		{
			foreach ($q->result() as $row)
			{
			  $data = $row;
			}
			return json_encode($data);
		}
	}	



public function update_agents($eid,$name,$address,$mobile,$email,$person,$company,$city,$state,$pin)
   {
	   
	
			 $my_array = array('name'=>$name,'address'=>$address,'mobile'=>$mobile,'email_id'=>$email,'person_name'=>$person,'company_name'=>$company,'city'=>$city,'state'=>$state,'pin'=>$pin);
			 $this->db->where("agent_id",$eid);
			 $this->db->update("d_agent",$my_array);
			 
			 $cnt=$this->db->affected_rows();
			 if(isset($cnt) && $cnt > 0)
			 {
				return json_encode(1);
			 }
			 else
			 {
				return json_encode(2); 
			 }
		   
	   
		 
    }	


//get_insurers    
    
    
public function get_insurer($id)
	{
		$this->db->select('*'); 
		$this->db->from('d_insurer');
		$my_array = array('insurer_id' => $id);
		$this->db->where($my_array);
		$this->db->limit(1);
		$q = $this->db->get();
		
		if($q->num_rows() > 0)
		{
			foreach ($q->result() as $row)
			{
			  $data = $row;
			}
			return json_encode($data);
		}
	}	



public function update_insurer($eid,$name)
   {
	   
	
		   
			 $my_array = array('name'=>$name);
			 $this->db->where("insurer_id",$eid);
			 $this->db->update("d_insurer",$my_array);
			 
			 $cnt=$this->db->affected_rows();
			 if(isset($cnt) && $cnt > 0)
			 {
				return json_encode(1);
			 }
			 else
			 {
				return json_encode(2); 
			 }
		   
	   
		 
    }	


//get_policy    
    
    
public function get_policy($id)
	{
		$this->db->select('*'); 
		$this->db->from('d_policy');
		$my_array = array('policy_id' => $id);
		$this->db->where($my_array);
		$this->db->limit(1);
		$q = $this->db->get();
		
		if($q->num_rows() > 0)
		{
			foreach ($q->result() as $row)
			{
			  $data = $row;
			}
			return json_encode($data);
		}
	}	


public function update_policy($eid,$type)
   {
	   
	
		   
			 $my_array = array('type'=>$type);
			 $this->db->where("policy_id",$eid);
			 $this->db->update("d_policy",$my_array);
			 
			 $cnt=$this->db->affected_rows();
			 if(isset($cnt) && $cnt > 0)
			 {
				return json_encode(1);
			 }
			 else
			 {
				return json_encode(2); 
			 }
		   
	   
		 
    }	
		
    
    //---------------------------------------------------------//
   
   
   public function  get_uploadedpolicy($eid) 
	{
                //$this->db->limit($limit, $start);
		$this->db->select('d_insurer.*,d_policy.*,files.*,d_uploaded_policy.*');
		$this->db->from('d_uploaded_policy');
                $this->db->join('d_insurer', 'd_uploaded_policy.insurer_id = d_insurer.insurer_id', 'inner');
                $this->db->join('d_policy', 'd_uploaded_policy.policy_id = d_policy.policy_id', 'inner');
                $this->db->join('files', 'd_uploaded_policy.file_id = files.id', 'inner');
                $array = array('d_uploaded_policy.up_id' => $eid);
               $this->db->where($array);
               $this->db->limit(1);
                //$this->db->order_by("up_id","desc");
		$q = $this->db->get();
	        if($q->num_rows() > 0)
		{
			foreach ($q->result() as $row)
			{
			  $data = $row;
			}
			return json_encode($data);
		}
   }
    
    
    //get_uploaded_policy    
    
    
public function get_uploaded_policy($id)
	{
		$this->db->select('*'); 
		$this->db->from('d_uploaded_policy');
		$my_array = array('up_id' => $id);
		$this->db->where($my_array);
		$this->db->limit(1);
		$q = $this->db->get();
		
		if($q->num_rows() > 0)
		{
			foreach ($q->result() as $row)
			{
			  $data = $row;
			}
			return json_encode($data);
		}
	}	


public function update_uploadedpolicy($eid,$policy_id,$insurer_id,$holder,$mobile,$email)
   {
	   
	
		   
			 $my_array = array('policy_id'=>$policy_id,'insurer_id'=>$insurer_id,'policy_holder_name'=>$holder,'mobile'=>$mobile,'email_id'=>$email);
			 $this->db->where("up_id",$eid);
			 $this->db->update("d_uploaded_policy",$my_array);
			 
			 $cnt=$this->db->affected_rows();
			 if(isset($cnt) && $cnt > 0)
			 {
				return json_encode(1);
			 }
			 else
			 {
				return json_encode(2); 
			 }
		   
	   
		 
    }	
    
    
//get_slider_images	
	
public function get_slider_images($id)
	{
		$this->db->select('*'); 
		$this->db->from('d_slider_images');
		$my_array = array('img_id' => $id);
		$this->db->where($my_array);
		$this->db->limit(1);
		$q = $this->db->get();
		
		if($q->num_rows() > 0)
		{
			foreach ($q->result() as $row)
			{
			  $data = $row;
			}
			return json_encode($data);
		}
	}	



public function update_slider_images($eid,$name)
   {
	   
	
			 $my_array = array('name'=>$name);
			 $this->db->where("img_id",$eid);
			 $this->db->update("d_slider_images",$my_array);
			 
			 $cnt=$this->db->affected_rows();
			 if(isset($cnt) && $cnt > 0)
			 {
				return json_encode(1);
			 }
			 else
			 {
				return json_encode(2); 
			 }
		   
	   
		 
    }	

}?>