<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Home_model extends CI_Model
{
	public function __construct()
	{
			$this->load->model("stringmodel"); 
			$this->load->helper('url');
			$this->load->library('session');
            $this->load->database();
			$this->load->helper('cookie');
			
	}


 
public function user_details()
   {
	    $this->db->select('*'); 
		$this->db->from('d_agent');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
        foreach ($query->result() as $row) {
        $data[] = $row;
        }
        return json_encode($data);
        }
       return false;
 }

 

  
	
	  
	
	
	
	

	
	
	
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
   
    
   
    
   
	

	
	
	
	
	
	
	

}

?>