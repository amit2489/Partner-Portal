<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class delete_model extends CI_Model
{
	public function __construct()
	{
		
		$this->load->model("edit_model");
		
	} 
   
	  public function delete_question($id)
     {
         $this->db->where('q_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('question');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      } 
	  
	  
	 public function delete_option($id)
     {
         $this->db->where('ex_option_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('exercise_option');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }



public function delete_agents($id)
     {
         $this->db->where('agent_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('d_agent');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }   




public function delete_insurer($id)
     {
         $this->db->where('insurer_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('d_insurer');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }  

      public function delete_policy($id)
     {
         $this->db->where('policy_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('d_policy');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }  

      
       public function delete_uploadedpolicy($id)
     {
         $this->db->where('up_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('d_uploaded_policy');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }  


	    
	  
   public function delete_slider_images($id)
   {
			$this->db->select('*'); 
			$this->db->from('d_slider_images');
			$this->db->where('img_id',$id);
			$this->db->limit(1);
			$q = $this->db->get();
			if($q->num_rows() > 0)
			{
				foreach ($q->result() as $row)
				{
				 $old_img=$row->name;
				 $old_thumb=$this->edit_model->generate_thumb($old_img);
				}
				@unlink("uploads/".$old_img);
				@unlink("uploads/".$old_thumb);
			}
			  
			  
			    $this->db->where('main_s_id',$id);
      			$this->db->limit(1);
      			$this->db->delete('main_slider');
			    $cnt=$this->db->affected_rows();
				
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
		  
	  
   }



  public function delete_txt_content($id)
   {
			$this->db->select('*'); 
			$this->db->from('text_content');
			$this->db->where('text_cont_id',$id);
			$this->db->limit(1);
			$q = $this->db->get();
			if($q->num_rows() > 0)
			{
				foreach ($q->result() as $row)
				{
				 $old_img=$row->c_image;
				 $old_thumb=$this->edit_model->generate_thumb($old_img);
				}
				@unlink("content_images/".$old_img);
				@unlink("content_images/".$old_thumb);
			}
			  
			  
			    $this->db->where('text_cont_id',$id);
      			$this->db->limit(1);
      			$this->db->delete('text_content');
			    $cnt=$this->db->affected_rows();
				
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
		  
	  
   }

 public function news_categorys($id)
     {
         $this->db->where('news_cat_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('news_category');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }


  public function delete_img($id)
   {
			$this->db->select('*'); 
			$this->db->from('vision_board');
			$this->db->where('id',$id);
			$this->db->limit(1);
			$q = $this->db->get();
			if($q->num_rows() > 0)
			{
				foreach ($q->result() as $row)
				{
				 $old_img=$row->image;
                              
				}
                                   
                                //echo  $path="/home/elitesol/public_html/upter/vision/".$old_img ;
                                //  $this->load->helper("file");
                                //  delete_files($path);
                               
				@unlink("/home/elitesol/public_html/upter/vision/".$old_img);
				
			}
			  
			  
			    $this->db->where('id',$id);
      			    $this->db->limit(1);
      			    $this->db->delete('vision_board');
			    $cnt=$this->db->affected_rows();
				
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
		  
	  
   }

public function delete_exercise($id)
     {
         $this->db->where('exercise_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('exercise');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }

public function delete_Belief($id)
     {
         $this->db->where('belief_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('belief');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }







public function delete_emotions($id)
     {
         $this->db->where('em_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('emotions_mgmt');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }
	




public function delete_option_em($id)
     {
         $this->db->where('em_option_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('em_option');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }




public function delete_emotions_sol($id)
     {
         $this->db->where('sol_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('emo_solution');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }







public function delete_tips($id)
     {
         $this->db->where('tip_id',$id);
      	 $this->db->limit(1);
      	 $this->db->delete('tips');
	     $cnt=$this->db->affected_rows();
				 if(isset($cnt) && $cnt > 0)
				 {
					return json_encode(1);
				 }
				 else
				 {
					return json_encode(2); 
				 }
      }







		   
} ?>
   